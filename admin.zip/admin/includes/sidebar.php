<?php
declare(strict_types=1);
require_once __DIR__ . '/functions.php';
$user = currentUser();
if (!$user || $user['role'] !== 'admin') return;
$currentScript = $_SERVER['PHP_SELF'];
$pdo = getDBConnection();
$unreadMessagesCount = getUnreadMessagesCount((int)$user['id']);
$pendingApprovalsCount = 0;
$pendingComplaintsCount = 0;
$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'boarder' AND status = 'pending'"); $pendingApprovalsCount = (int)$stmt->fetchColumn();
function isActiveNav(string $path, string $currentScript): string { return str_contains($currentScript, $path) ? 'active' : ''; }
?>
<aside class="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg></div>
    <div class="brand-text"><h2>HOSTEL MGR</h2><span>Seat & Mess System</span></div>
  </div>
  <nav class="sidebar-nav">
    <span class="nav-section-title">Administration</span>
    <a href="<?= BASE_URL ?>/dashboard.php" class="nav-link <?= isActiveNav('/dashboard.php', $currentScript) ?>"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"></rect></svg><span>Overview</span></a>
    <a href="<?= BASE_URL ?>/managers.php" class="nav-link <?= isActiveNav('/managers.php', $currentScript) ?>"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"></rect></svg><span>Hostel Managers</span></a>
    <a href="<?= BASE_URL ?>/hostels.php" class="nav-link <?= isActiveNav('/hostels.php', $currentScript) ?>"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"></rect></svg><span>Hostels & Blocks</span></a>
    <a href="<?= BASE_URL ?>/rooms.php" class="nav-link <?= isActiveNav('/rooms.php', $currentScript) ?>"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"></rect></svg><span>Rooms & Floors</span></a>
    <a href="<?= BASE_URL ?>/beds.php" class="nav-link <?= isActiveNav('/beds.php', $currentScript) ?>"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"></rect></svg><span>Bed Inventory</span></a>
    <a href="<?= BASE_URL ?>/approvals.php" class="nav-link <?= isActiveNav('/approvals.php', $currentScript) ?>"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"></rect></svg><span>Approvals</span><?php if ($pendingApprovalsCount > 0): ?><span class="nav-badge badge-danger"><?= $pendingApprovalsCount ?></span><?php endif; ?></a>
    <a href="<?= BASE_URL ?>/notices.php" class="nav-link <?= isActiveNav('/notices.php', $currentScript) ?>"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"></rect></svg><span>Broadcast Notices</span></a>
    <a href="<?= BASE_URL ?>/reports.php" class="nav-link <?= isActiveNav('/reports.php', $currentScript) ?>"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"></rect></svg><span>Financial Reports</span></a>
    <span class="nav-section-title">Settings</span>
    <a href="<?= BASE_URL ?>/profile.php" class="nav-link <?= isActiveNav('/profile.php', $currentScript) ?>"><svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg><span>My Profile</span></a>
    <a href="<?= BASE_URL ?>/logout.php" class="nav-link" style="color:#f87171;"><svg viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg><span>Sign Out</span></a>
  </nav>
  <div class="sidebar-user"><div class="user-avatar"><?= strtoupper(substr($user['name'], 0, 1)) ?></div><div class="user-info"><div class="user-name"><?= e($user['name']) ?></div><div class="user-role"><?= e(str_replace('_', ' ', $user['role'])) ?></div></div></div>
</aside>
<div class="sidebar-backdrop"></div>
