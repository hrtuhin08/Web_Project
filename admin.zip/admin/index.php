<?php
declare(strict_types=1);
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
$user=currentUser();
if ($user && ($user['role'] ?? '') === 'admin') { header('Location: ' . BASE_URL . '/dashboard.php'); } else { header('Location: ' . BASE_URL . '/login.php'); }
exit;
