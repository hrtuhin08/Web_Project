<?php





declare(strict_types=1);
$required_role = 'admin';
require_once __DIR__ . '/includes/role_check.php';

$pdo = getDBConnection();

$stmt = $pdo->query("
    SELECT n.*, u.name as author_name 
    FROM notices n
    LEFT JOIN users u ON n.created_by = u.id
    ORDER BY n.publish_date DESC, n.id DESC
");
$notices = $stmt->fetchAll();

$page_title = 'Broadcast Notices';
$page_heading = 'Broadcast Notices';
$page_subheading = 'Publish urgent notices, meal time changes, and residential announcements';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      <div class="table-toolbar">
        <div>
          <h3 style="font-size: 1.15rem; font-weight: 700;">Announcements & Bulletins</h3>
          <p style="font-size: 0.82rem; color: var(--text-muted);">Notices automatically display on target user dashboards</p>
        </div>
        <button class="btn btn-primary" onclick="openModal('addNoticeModal')">+ Create Notice</button>
      </div>

      <div class="card">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Priority</th>
                <th>Target Audience</th>
                <th>Published Date</th>
                <th>Author</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($notices)): ?>
                <?php foreach ($notices as $n): ?>
                  <tr>
                    <td>
                      <strong><?= e($n['title']) ?></strong>
                      <p style="font-size: 0.82rem; color: var(--text-muted); margin-top: 0.25rem;">
                        <?= e(substr($n['description'], 0, 100)) ?>...
                      </p>
                    </td>
                    <td>
                      <span class="badge badge-<?= strtolower(e($n['priority'])) ?>">
                        <?= e($n['priority']) ?>
                      </span>
                    </td>
                    <td><span class="badge badge-info"><?= e($n['target_role']) ?></span></td>
                    <td class="font-mono"><?= formatDate($n['publish_date']) ?></td>
                    <td><?= e($n['author_name'] ?? 'Admin') ?></td>
                    <td>
                      <form method="POST" action="<?= BASE_URL ?>/actions/notice.php" onsubmit="return confirm('Delete this notice?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="notice_id" value="<?= $n['id'] ?>">
                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="6" style="text-align: center; padding: 2rem;">No notices published.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div> 

    
    <div class="modal-backdrop" id="addNoticeModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Create Broadcast Notice</h3>
          <button class="modal-close" onclick="closeModal('addNoticeModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/notice.php" data-validate="true">
          <input type="hidden" name="action" value="create">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Notice Title <span class="required">*</span></label>
              <input type="text" name="title" class="form-control" required placeholder="e.g. Mess Dining Timings for Exams">
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Priority Level <span class="required">*</span></label>
                <select name="priority" class="form-control" required>
                  <option value="Normal">Normal</option>
                  <option value="Important" selected>Important</option>
                  <option value="Urgent">Urgent</option>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Target Audience <span class="required">*</span></label>
                <select name="target_role" class="form-control" required>
                  <option value="All" selected>All Users</option>
                  <option value="Boarder">Boarders / Students Only</option>
                  <option value="Manager">Hostel Managers Only</option>
                  <option value="Mess Staff">Mess Staff Only</option>
                </select>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Publish Date <span class="required">*</span></label>
              <input type="date" name="publish_date" class="form-control" required value="<?= date('Y-m-d') ?>">
            </div>

            <div class="form-group">
              <label class="form-label">Notice Announcement Body <span class="required">*</span></label>
              <textarea name="description" class="form-control" rows="4" required placeholder="Write the complete notice announcement details here..."></textarea>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('addNoticeModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Broadcast Notice</button>
          </div>
        </form>
      </div>
    </div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
