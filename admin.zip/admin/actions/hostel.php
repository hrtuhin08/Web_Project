<?php





declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !hasRole('admin')) {
    setFlash('error', 'Unauthorized access.');
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user = currentUser();
$pdo = getDBConnection();
$action = $_POST['action'] ?? '';
$csrfToken = $_POST['csrf_token'] ?? '';

if (!verifyCSRFToken($csrfToken)) {
    setFlash('error', 'Security token mismatch.');
    header('Location: ' . BASE_URL . '/admin/hostels.php');
    exit;
}

if ($action === 'create') {
    $name = trim($_POST['name'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $capacity = (int)($_POST['total_capacity'] ?? 0);

    if (empty($name) || empty($address)) {
        setFlash('error', 'Hostel name and address are required.');
    } else {
        $stmt = $pdo->prepare("INSERT INTO hostels (name, address, description, total_capacity, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$name, $address, $description, $capacity]);
        logActivity((int)$user['id'], 'Created Hostel', "Created hostel '{$name}'");
        setFlash('success', 'Hostel created successfully.');
    }
} elseif ($action === 'update') {
    $id = (int)($_POST['hostel_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $capacity = (int)($_POST['total_capacity'] ?? 0);

    if ($id > 0 && !empty($name)) {
        $stmt = $pdo->prepare("UPDATE hostels SET name = ?, address = ?, description = ?, total_capacity = ? WHERE id = ?");
        $stmt->execute([$name, $address, $description, $capacity, $id]);
        logActivity((int)$user['id'], 'Updated Hostel', "Updated hostel ID {$id}");
        setFlash('success', 'Hostel details updated.');
    }
} elseif ($action === 'delete') {
    $id = (int)($_POST['hostel_id'] ?? 0);
    if ($id > 0) {
        $stmt = $pdo->prepare("DELETE FROM hostels WHERE id = ?");
        $stmt->execute([$id]);
        logActivity((int)$user['id'], 'Deleted Hostel', "Deleted hostel ID {$id}");
        setFlash('success', 'Hostel deleted.');
    }
}

header('Location: ' . BASE_URL . '/admin/hostels.php');
exit;
