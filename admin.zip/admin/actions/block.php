<?php





declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !hasRole('admin')) {
    setFlash('error', 'Unauthorized access.');
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user = currentUser();
$pdo = getDBConnection();
$action = $_POST['action'] ?? '';
$csrfToken = $_POST['csrf_token'] ?? '';

if (!verifyCSRFToken($csrfToken)) {
    setFlash('error', 'Security token invalid.');
    header('Location: ' . BASE_URL . '/admin/hostels.php');
    exit;
}

if ($action === 'create') {
    $hostelId = (int)($_POST['hostel_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');

    if ($hostelId > 0 && !empty($name)) {
        $stmt = $pdo->prepare("INSERT INTO blocks (hostel_id, name, created_at) VALUES (?, ?, NOW())");
        $stmt->execute([$hostelId, $name]);
        logActivity((int)$user['id'], 'Created Block', "Created block '{$name}' for hostel ID {$hostelId}");
        setFlash('success', 'Block successfully added.');
    } else {
        setFlash('error', 'Block name and hostel selection required.');
    }
} elseif ($action === 'update') {
    $id = (int)($_POST['block_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    if ($id > 0 && !empty($name)) {
        $stmt = $pdo->prepare("UPDATE blocks SET name = ? WHERE id = ?");
        $stmt->execute([$name, $id]);
        setFlash('success', 'Block name updated.');
    }
} elseif ($action === 'delete') {
    $id = (int)($_POST['block_id'] ?? 0);
    if ($id > 0) {
        $stmt = $pdo->prepare("DELETE FROM blocks WHERE id = ?");
        $stmt->execute([$id]);
        setFlash('success', 'Block removed.');
    }
}

header('Location: ' . BASE_URL . '/admin/hostels.php');
exit;
