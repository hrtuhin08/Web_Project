<?php





declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !hasRole('admin')) {
    setFlash('error', 'Unauthorized.');
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$pdo = getDBConnection();
$action = $_POST['action'] ?? '';
$csrfToken = $_POST['csrf_token'] ?? '';

if (!verifyCSRFToken($csrfToken)) {
    setFlash('error', 'Invalid token.');
    header('Location: ' . BASE_URL . '/admin/rooms.php');
    exit;
}

if ($action === 'create') {
    $blockId = (int)($_POST['block_id'] ?? 0);
    $floorNumber = trim($_POST['floor_number'] ?? '');

    if ($blockId > 0 && !empty($floorNumber)) {
        $stmt = $pdo->prepare("INSERT INTO floors (block_id, floor_number, created_at) VALUES (?, ?, NOW())");
        $stmt->execute([$blockId, $floorNumber]);
        setFlash('success', 'Floor added successfully.');
    } else {
        setFlash('error', 'Floor number and block are required.');
    }
} elseif ($action === 'delete') {
    $id = (int)($_POST['floor_id'] ?? 0);
    if ($id > 0) {
        $pdo->prepare("DELETE FROM floors WHERE id = ?")->execute([$id]);
        setFlash('success', 'Floor removed.');
    }
}

header('Location: ' . BASE_URL . '/admin/rooms.php');
exit;
