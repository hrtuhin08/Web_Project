<?php





declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !hasRole('admin')) {
    setFlash('error', 'Unauthorized access.');
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user = currentUser();
$pdo = getDBConnection();
$action = $_POST['action'] ?? '';
$csrfToken = $_POST['csrf_token'] ?? '';

if (!verifyCSRFToken($csrfToken)) {
    setFlash('error', 'Security token mismatch.');
    header('Location: ' . BASE_URL . '/admin/managers.php');
    exit;
}

if ($action === 'create') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $hostelId = (int)($_POST['hostel_id'] ?? 0);
    $status = $_POST['status'] ?? 'active';

    if (empty($name) || empty($email) || empty($phone) || empty($password) || $hostelId <= 0) {
        setFlash('error', 'All fields and assigned hostel are required.');
    } else {
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);
        if ($check->fetch()) {
            setFlash('error', 'A user with this email already exists.');
        } else {
            try {
                $pdo->beginTransaction();
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, password, role, status, created_at) VALUES (?, ?, ?, ?, 'manager', ?, NOW())");
                $stmt->execute([$name, $email, $phone, $hash, $status]);
                $managerId = (int)$pdo->lastInsertId();

                $assignStmt = $pdo->prepare("INSERT INTO manager_assignments (manager_id, hostel_id, assigned_at) VALUES (?, ?, NOW())");
                $assignStmt->execute([$managerId, $hostelId]);

                logActivity((int)$user['id'], 'Created Manager', "Created manager {$name} assigned to hostel ID {$hostelId}");
                $pdo->commit();
                setFlash('success', 'Hostel Manager successfully created and assigned.');
            } catch (Exception $e) {
                $pdo->rollBack();
                setFlash('error', 'Failed to create manager: ' . $e->getMessage());
            }
        }
    }
} elseif ($action === 'update') {
    $managerId = (int)($_POST['manager_id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $hostelId = (int)($_POST['hostel_id'] ?? 0);
    $status = $_POST['status'] ?? 'active';
    $newPassword = $_POST['password'] ?? '';

    if ($managerId <= 0 || empty($name) || empty($phone) || $hostelId <= 0) {
        setFlash('error', 'Invalid update parameters.');
    } else {
        try {
            $pdo->beginTransaction();
            if (!empty($newPassword)) {
                $hash = password_hash($newPassword, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("UPDATE users SET name = ?, phone = ?, password = ?, status = ? WHERE id = ? AND role = 'manager'");
                $stmt->execute([$name, $phone, $hash, $status, $managerId]);
            } else {
                $stmt = $pdo->prepare("UPDATE users SET name = ?, phone = ?, status = ? WHERE id = ? AND role = 'manager'");
                $stmt->execute([$name, $phone, $status, $managerId]);
            }

            
            $pdo->prepare("DELETE FROM manager_assignments WHERE manager_id = ?")->execute([$managerId]);
            $pdo->prepare("INSERT INTO manager_assignments (manager_id, hostel_id, assigned_at) VALUES (?, ?, NOW())")->execute([$managerId, $hostelId]);

            logActivity((int)$user['id'], 'Updated Manager', "Updated manager ID {$managerId}");
            $pdo->commit();
            setFlash('success', 'Manager details updated successfully.');
        } catch (Exception $e) {
            $pdo->rollBack();
            setFlash('error', 'Failed to update manager.');
        }
    }
} elseif ($action === 'delete') {
    $managerId = (int)($_POST['manager_id'] ?? 0);
    if ($managerId > 0) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'manager'");
        $stmt->execute([$managerId]);
        logActivity((int)$user['id'], 'Deleted Manager', "Deleted manager ID {$managerId}");
        setFlash('success', 'Manager removed.');
    }
}

header('Location: ' . BASE_URL . '/admin/managers.php');
exit;
