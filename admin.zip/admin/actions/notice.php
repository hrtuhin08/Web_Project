<?php





declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !hasRole(['admin', 'manager'])) {
    setFlash('error', 'Unauthorized.');
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user = currentUser();
$pdo = getDBConnection();
$action = $_POST['action'] ?? '';
$csrfToken = $_POST['csrf_token'] ?? '';

if (!verifyCSRFToken($csrfToken)) {
    setFlash('error', 'Security token expired.');
    header('Location: ' . BASE_URL . '/admin/notices.php');
    exit;
}

if ($action === 'create') {
    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $priority = $_POST['priority'] ?? 'Normal';
    $targetRole = $_POST['target_role'] ?? 'All';
    $publishDate = $_POST['publish_date'] ?? date('Y-m-d');

    if (empty($title) || empty($description)) {
        setFlash('error', 'Notice title and details are required.');
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO notices (title, description, priority, target_role, created_by, publish_date, created_at)
            VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([$title, $description, $priority, $targetRole, $user['id'], $publishDate]);
        logActivity((int)$user['id'], 'Published Notice', "Published notice: '{$title}'");
        setFlash('success', 'Notice published successfully.');
    }
} elseif ($action === 'delete') {
    $noticeId = (int)($_POST['notice_id'] ?? 0);
    if ($noticeId > 0) {
        $pdo->prepare("DELETE FROM notices WHERE id = ?")->execute([$noticeId]);
        logActivity((int)$user['id'], 'Deleted Notice', "Deleted notice ID {$noticeId}");
        setFlash('success', 'Notice deleted.');
    }
}

header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/admin/notices.php')));
exit;
