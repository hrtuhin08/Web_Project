<?php





declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !hasRole('admin')) {
    setFlash('error', 'Unauthorized access.');
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user = currentUser();
$pdo = getDBConnection();
$action = $_POST['action'] ?? '';
$userId = (int)($_POST['user_id'] ?? 0);
$csrfToken = $_POST['csrf_token'] ?? '';

if (!verifyCSRFToken($csrfToken)) {
    setFlash('error', 'Security token mismatch.');
    header('Location: ' . BASE_URL . '/admin/approvals.php');
    exit;
}

if ($userId > 0) {
    if ($action === 'approve') {
        $stmt = $pdo->prepare("UPDATE users SET status = 'approved' WHERE id = ? AND role = 'boarder'");
        $stmt->execute([$userId]);
        logActivity((int)$user['id'], 'Approved Boarder', "Approved boarder user ID {$userId}");
        setFlash('success', 'Student boarder approved! They are now eligible for seat allocation.');
    } elseif ($action === 'reject') {
        $stmt = $pdo->prepare("UPDATE users SET status = 'rejected' WHERE id = ? AND role = 'boarder'");
        $stmt->execute([$userId]);
        logActivity((int)$user['id'], 'Rejected Boarder', "Rejected boarder user ID {$userId}");
        setFlash('warning', 'Boarder application has been marked as rejected.');
    }
}

header('Location: ' . BASE_URL . '/admin/approvals.php');
exit;
