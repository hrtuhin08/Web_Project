<?php





declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !hasRole('admin')) {
    setFlash('error', 'Unauthorized.');
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user = currentUser();
$pdo = getDBConnection();
$action = $_POST['action'] ?? '';
$csrfToken = $_POST['csrf_token'] ?? '';

if (!verifyCSRFToken($csrfToken)) {
    setFlash('error', 'Security token mismatch.');
    header('Location: ' . BASE_URL . '/admin/rooms.php');
    exit;
}

if ($action === 'create') {
    $floorId = (int)($_POST['floor_id'] ?? 0);
    $roomNumber = trim($_POST['room_number'] ?? '');
    $roomType = $_POST['room_type'] ?? 'double';
    $rent = (float)($_POST['rent'] ?? 3500.00);
    $status = $_POST['status'] ?? 'active';
    $autoBeds = isset($_POST['auto_generate_beds']);

    if ($floorId <= 0 || empty($roomNumber)) {
        setFlash('error', 'Floor selection and room number are required.');
    } else {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("INSERT INTO rooms (floor_id, room_number, room_type, rent, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$floorId, $roomNumber, $roomType, $rent, $status]);
            $roomId = (int)$pdo->lastInsertId();

            
            if ($autoBeds) {
                $bedCounts = ['single' => 1, 'double' => 2, 'triple' => 3, 'quad' => 4];
                $numBeds = $bedCounts[$roomType] ?? 2;
                $bedStmt = $pdo->prepare("INSERT INTO beds (room_id, bed_number, status, created_at) VALUES (?, ?, 'vacant', NOW())");
                for ($i = 1; $i <= $numBeds; $i++) {
                    $bedStmt->execute([$roomId, 'B' . $i]);
                }
            }

            logActivity((int)$user['id'], 'Created Room', "Created room {$roomNumber} ({$roomType}) on floor ID {$floorId}");
            $pdo->commit();
            setFlash('success', 'Room added successfully.');
        } catch (Exception $e) {
            $pdo->rollBack();
            setFlash('error', 'Failed to create room: ' . $e->getMessage());
        }
    }
} elseif ($action === 'update') {
    $roomId = (int)($_POST['room_id'] ?? 0);
    $roomNumber = trim($_POST['room_number'] ?? '');
    $roomType = $_POST['room_type'] ?? 'double';
    $rent = (float)($_POST['rent'] ?? 3500.00);
    $status = $_POST['status'] ?? 'active';

    if ($roomId > 0 && !empty($roomNumber)) {
        $stmt = $pdo->prepare("UPDATE rooms SET room_number = ?, room_type = ?, rent = ?, status = ? WHERE id = ?");
        $stmt->execute([$roomNumber, $roomType, $rent, $status, $roomId]);
        logActivity((int)$user['id'], 'Updated Room', "Updated room ID {$roomId}");
        setFlash('success', 'Room updated successfully.');
    }
} elseif ($action === 'delete') {
    $roomId = (int)($_POST['room_id'] ?? 0);
    if ($roomId > 0) {
        $pdo->prepare("DELETE FROM rooms WHERE id = ?")->execute([$roomId]);
        logActivity((int)$user['id'], 'Deleted Room', "Deleted room ID {$roomId}");
        setFlash('success', 'Room deleted.');
    }
}

header('Location: ' . BASE_URL . '/admin/rooms.php');
exit;
