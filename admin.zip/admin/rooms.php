<?php





declare(strict_types=1);
$required_role = 'admin';
require_once __DIR__ . '/includes/role_check.php';

$pdo = getDBConnection();

$selectedHostelId = (int)($_GET['hostel_id'] ?? 0);


$hostels = $pdo->query("SELECT id, name FROM hostels ORDER BY name ASC")->fetchAll();


$floorsStmt = $pdo->query("
    SELECT f.id, f.floor_number, bl.name as block_name, h.name as hostel_name
    FROM floors f
    JOIN blocks bl ON f.block_id = bl.id
    JOIN hostels h ON bl.hostel_id = h.id
    ORDER BY h.id ASC, bl.id ASC, f.floor_number ASC
");
$allFloors = $floorsStmt->fetchAll();


$blocksStmt = $pdo->query("
    SELECT bl.id, bl.name, h.name as hostel_name 
    FROM blocks bl 
    JOIN hostels h ON bl.hostel_id = h.id 
    ORDER BY h.name ASC, bl.name ASC
");
$allBlocks = $blocksStmt->fetchAll();


$roomSql = "
    SELECT 
        r.*,
        f.floor_number,
        bl.name as block_name,
        h.name as hostel_name,
        COUNT(b.id) as bed_count,
        SUM(CASE WHEN b.status = 'occupied' THEN 1 ELSE 0 END) as occupied_count
    FROM rooms r
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    JOIN hostels h ON bl.hostel_id = h.id
    LEFT JOIN beds b ON b.room_id = r.id
";

$params = [];
if ($selectedHostelId > 0) {
    $roomSql .= " WHERE h.id = :hid";
    $params['hid'] = $selectedHostelId;
}

$roomSql .= " GROUP BY r.id, f.floor_number, bl.name, h.name, bl.id, h.id ORDER BY h.id ASC, bl.id ASC, r.room_number ASC";

$stmt = $pdo->prepare($roomSql);
$stmt->execute($params);
$rooms = $stmt->fetchAll();


$floorsSql = "
    SELECT 
        f.id, 
        f.floor_number, 
        bl.name as block_name, 
        h.name as hostel_name,
        COUNT(DISTINCT r.id) as room_count,
        COUNT(DISTINCT b.id) as bed_count
    FROM floors f
    JOIN blocks bl ON f.block_id = bl.id
    JOIN hostels h ON bl.hostel_id = h.id
    LEFT JOIN rooms r ON r.floor_id = f.id
    LEFT JOIN beds b ON b.room_id = r.id
";
$floorParams = [];
if ($selectedHostelId > 0) {
    $floorsSql .= " WHERE h.id = :hid";
    $floorParams['hid'] = $selectedHostelId;
}
$floorsSql .= " GROUP BY f.id, f.floor_number, bl.name, h.name ORDER BY h.name ASC, bl.name ASC, f.floor_number ASC";
$fStmt = $pdo->prepare($floorsSql);
$fStmt->execute($floorParams);
$floorList = $fStmt->fetchAll();

$page_title = 'Rooms & Floors';
$page_heading = 'Rooms & Floor Configurations';
$page_subheading = 'Manage room capacity, types, rates, and occupancy';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      <div class="table-toolbar">
        
        <div style="display: flex; align-items: center; gap: 0.75rem;">
          <label class="form-label" style="margin: 0;">Filter Hostel:</label>
          <select class="form-control" style="width: auto;" onchange="location.href='<?= BASE_URL ?>/admin/rooms.php?hostel_id=' + this.value;">
            <option value="0">All Hostels</option>
            <?php foreach ($hostels as $h): ?>
              <option value="<?= $h['id'] ?>" <?= $selectedHostelId === (int)$h['id'] ? 'selected' : '' ?>>
                <?= e($h['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div style="display: flex; gap: 0.75rem;">
          <button class="btn btn-secondary" onclick="openModal('addFloorModal')">+ Add Floor</button>
          <button class="btn btn-primary" onclick="openModal('addRoomModal')">+ Add Room</button>
        </div>
      </div>

      <div class="card">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Room No</th>
                <th>Hostel & Block</th>
                <th>Floor</th>
                <th>Room Type</th>
                <th>Monthly Rent</th>
                <th>Beds (Occupied / Total)</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($rooms)): ?>
                <?php foreach ($rooms as $room): ?>
                  <tr>
                    <td><strong><?= e($room['room_number']) ?></strong></td>
                    <td>
                      <div><?= e($room['hostel_name']) ?></div>
                      <span style="font-size: 0.78rem; color: var(--text-muted);"><?= e($room['block_name']) ?></span>
                    </td>
                    <td><?= e($room['floor_number']) ?></td>
                    <td><span class="badge badge-info"><?= ucfirst(e($room['room_type'])) ?></span></td>
                    <td class="font-mono"><?= formatCurrency($room['rent']) ?></td>
                    <td class="font-mono">
                      <span style="color: <?= $room['occupied_count'] > 0 ? 'var(--danger)' : 'var(--text-muted)' ?>; font-weight: 700;">
                        <?= (int)$room['occupied_count'] ?>
                      </span> / <?= (int)$room['bed_count'] ?> Beds
                    </td>
                    <td>
                      <span class="badge badge-<?= $room['status'] === 'active' ? 'active' : 'maintenance' ?>">
                        <?= ucfirst(e($room['status'])) ?>
                      </span>
                    </td>
                    <td>
                      <div class="actions-cell">
                        <button class="btn btn-secondary btn-sm" onclick='editRoom(<?= json_encode($room) ?>)'>Edit</button>
                        <form method="POST" action="<?= BASE_URL ?>/actions/room.php" onsubmit="return confirm('Deleting room will delete its beds. Continue?');" style="display: inline;">
                          <input type="hidden" name="action" value="delete">
                          <input type="hidden" name="room_id" value="<?= $room['id'] ?>">
                          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                          <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="8" style="text-align: center; padding: 2rem;">No rooms found matching filter.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      
      <div class="card" style="margin-top: 2rem;">
        <div class="card-header">
          <div>
            <h3 class="card-title">Floor Levels Inventory</h3>
            <p class="card-subtitle">Configured floor levels and capacity across residential blocks</p>
          </div>
          <button class="btn btn-secondary btn-sm" onclick="openModal('addFloorModal')">+ Add Floor</button>
        </div>

        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Floor Level</th>
                <th>Hostel & Block</th>
                <th>Rooms Count</th>
                <th>Total Beds Capacity</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($floorList)): ?>
                <?php foreach ($floorList as $flItem): ?>
                  <tr>
                    <td><strong><?= e($flItem['floor_number']) ?></strong></td>
                    <td>
                      <div><?= e($flItem['hostel_name']) ?></div>
                      <span style="font-size: 0.78rem; color: var(--text-muted);"><?= e($flItem['block_name']) ?></span>
                    </td>
                    <td class="font-mono"><?= (int)$flItem['room_count'] ?> Rooms</td>
                    <td class="font-mono"><?= (int)$flItem['bed_count'] ?> Beds</td>
                    <td>
                      <form method="POST" action="<?= BASE_URL ?>/actions/floor.php" onsubmit="return confirm('Deleting floor will delete all its rooms and beds. Continue?');" style="display: inline;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="floor_id" value="<?= $flItem['id'] ?>">
                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="5" style="text-align: center; padding: 2rem;">No floors found matching filter.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div> 

    
    <div class="modal-backdrop" id="addRoomModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Add New Room</h3>
          <button class="modal-close" onclick="closeModal('addRoomModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/room.php" data-validate="true">
          <input type="hidden" name="action" value="create">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Floor & Block <span class="required">*</span></label>
              <select name="floor_id" class="form-control" required>
                <option value="">-- Choose Floor Location --</option>
                <?php foreach ($allFloors as $fl): ?>
                  <option value="<?= $fl['id'] ?>">
                    <?= e($fl['hostel_name']) ?> &rsaquo; <?= e($fl['block_name']) ?> &rsaquo; <?= e($fl['floor_number']) ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Room Number / ID <span class="required">*</span></label>
                <input type="text" name="room_number" class="form-control" required placeholder="e.g. Room 204">
              </div>

              <div class="form-group">
                <label class="form-label">Room Type <span class="required">*</span></label>
                <select name="room_type" class="form-control" required>
                  <option value="single">Single (1 Bed)</option>
                  <option value="double" selected>Double (2 Beds)</option>
                  <option value="triple">Triple (3 Beds)</option>
                  <option value="quad">Quad (4 Beds)</option>
                </select>
              </div>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Monthly Rent (BDT) <span class="required">*</span></label>
                <input type="number" step="50" name="rent" class="form-control" required value="3500">
              </div>

              <div class="form-group">
                <label class="form-label">Room Operational Status</label>
                <select name="status" class="form-control">
                  <option value="active">Active</option>
                  <option value="maintenance">Maintenance</option>
                </select>
              </div>
            </div>

            <div class="form-group" style="margin-top: 0.5rem; background: #f8fafc; padding: 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color);">
              <label class="custom-checkbox">
                <input type="checkbox" name="auto_generate_beds" value="1" checked>
                <span><strong>Automatically generate bed inventory</strong> (e.g. B1, B2) for this room</span>
              </label>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('addRoomModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Create Room</button>
          </div>
        </form>
      </div>
    </div>

    
    <div class="modal-backdrop" id="editRoomModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Edit Room</h3>
          <button class="modal-close" onclick="closeModal('editRoomModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/room.php" data-validate="true">
          <input type="hidden" name="action" value="update">
          <input type="hidden" name="room_id" id="edit_room_id">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Room Number <span class="required">*</span></label>
              <input type="text" name="room_number" id="edit_r_num" class="form-control" required>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Room Type</label>
                <select name="room_type" id="edit_r_type" class="form-control">
                  <option value="single">Single</option>
                  <option value="double">Double</option>
                  <option value="triple">Triple</option>
                  <option value="quad">Quad</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">Monthly Rent (BDT)</label>
                <input type="number" step="50" name="rent" id="edit_r_rent" class="form-control" required>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Status</label>
              <select name="status" id="edit_r_status" class="form-control">
                <option value="active">Active</option>
                <option value="maintenance">Maintenance</option>
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('editRoomModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Update Room</button>
          </div>
        </form>
      </div>
    </div>

    
    <div class="modal-backdrop" id="addFloorModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Add Floor Level</h3>
          <button class="modal-close" onclick="closeModal('addFloorModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/floor.php" data-validate="true">
          <input type="hidden" name="action" value="create">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Block <span class="required">*</span></label>
              <select name="block_id" class="form-control" required>
                <?php foreach ($allBlocks as $b): ?>
                  <option value="<?= $b['id'] ?>"><?= e($b['hostel_name']) ?> - <?= e($b['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Floor Designation <span class="required">*</span></label>
              <input type="text" name="floor_number" class="form-control" required placeholder="e.g. 3rd Floor, Ground Floor">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('addFloorModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Save Floor</button>
          </div>
        </form>
      </div>
    </div>

  <script>
    function editRoom(r) {
      document.getElementById('edit_room_id').value = r.id;
      document.getElementById('edit_r_num').value = r.room_number;
      document.getElementById('edit_r_type').value = r.room_type;
      document.getElementById('edit_r_rent').value = r.rent;
      document.getElementById('edit_r_status').value = r.status;
      openModal('editRoomModal');
    }
  </script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
