<?php





declare(strict_types=1);
$required_role = 'admin';
require_once __DIR__ . '/includes/role_check.php';

$pdo = getDBConnection();


$pendingStmt = $pdo->query("
    SELECT u.id as user_id, u.name, u.email, u.phone, u.status, u.created_at,
           b.id as boarder_id, b.student_id, b.institution, b.department, b.guardian_name, b.guardian_phone, b.address
    FROM users u
    JOIN boarders b ON b.user_id = u.id
    WHERE u.role = 'boarder' AND u.status = 'pending'
    ORDER BY u.id ASC
");
$pendingApplicants = $pendingStmt->fetchAll();


$processedStmt = $pdo->query("
    SELECT u.id as user_id, u.name, u.email, u.phone, u.status, u.updated_at,
           b.student_id, b.institution, b.department
    FROM users u
    JOIN boarders b ON b.user_id = u.id
    WHERE u.role = 'boarder' AND u.status IN ('approved', 'active', 'rejected')
    ORDER BY u.updated_at DESC
    LIMIT 10
");
$processedApplicants = $processedStmt->fetchAll();

$page_title = 'Account Approvals';
$page_heading = 'Student Admission Approvals';
$page_subheading = 'Review, approve, or reject new boarder registration requests';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      
      <div class="card" style="margin-bottom: 2rem;">
        <div class="card-header">
          <div>
            <h3 class="card-title">Pending Admission Queue</h3>
            <p class="card-subtitle">Verify academic eligibility before admitting boarders to seat allocation</p>
          </div>
          <span class="badge badge-<?= count($pendingApplicants) > 0 ? 'warning' : 'success' ?>">
            <?= count($pendingApplicants) ?> Pending Review
          </span>
        </div>

        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Applicant</th>
                <th>Student ID</th>
                <th>Institution & Major</th>
                <th>Guardian Contact</th>
                <th>Applied Date</th>
                <th>Decision Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($pendingApplicants)): ?>
                <?php foreach ($pendingApplicants as $app): ?>
                  <tr>
                    <td>
                      <strong><?= e($app['name']) ?></strong>
                      <div style="font-size: 0.8rem; color: var(--text-muted);"><?= e($app['email']) ?> | <?= e($app['phone']) ?></div>
                    </td>
                    <td><span class="font-mono" style="font-weight: 700;"><?= e($app['student_id']) ?></span></td>
                    <td>
                      <div><?= e($app['institution']) ?></div>
                      <span style="font-size: 0.8rem; color: var(--text-muted);"><?= e($app['department']) ?></span>
                    </td>
                    <td>
                      <div><?= e($app['guardian_name']) ?></div>
                      <div style="font-size: 0.8rem; color: var(--text-muted);"><?= e($app['guardian_phone']) ?></div>
                    </td>
                    <td class="font-mono" style="font-size: 0.8rem;"><?= formatDate($app['created_at']) ?></td>
                    <td>
                      <div class="actions-cell">
                        <form method="POST" action="<?= BASE_URL ?>/actions/approval.php" style="display: inline;">
                          <input type="hidden" name="action" value="approve">
                          <input type="hidden" name="user_id" value="<?= $app['user_id'] ?>">
                          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                          <button type="submit" class="btn btn-success btn-sm">Approve</button>
                        </form>

                        <form method="POST" action="<?= BASE_URL ?>/actions/approval.php" onsubmit="return confirm('Reject this student application?');" style="display: inline;">
                          <input type="hidden" name="action" value="reject">
                          <input type="hidden" name="user_id" value="<?= $app['user_id'] ?>">
                          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                          <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                        </form>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="6" style="text-align: center; padding: 2.5rem; color: var(--text-muted);">
                    <div style="font-size: 2rem; margin-bottom: 0.5rem;">✅</div>
                    <strong>No pending admission applications.</strong> All students have been processed.
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      
      <div class="card">
        <div class="card-header">
          <div>
            <h3 class="card-title">Recently Processed Applicants</h3>
            <p class="card-subtitle">Approved or rejected student accounts</p>
          </div>
        </div>

        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Student</th>
                <th>Student ID</th>
                <th>Department</th>
                <th>Status</th>
                <th>Updated</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($processedApplicants)): ?>
                <?php foreach ($processedApplicants as $p): ?>
                  <tr>
                    <td><strong><?= e($p['name']) ?></strong></td>
                    <td class="font-mono"><?= e($p['student_id']) ?></td>
                    <td><?= e($p['department']) ?></td>
                    <td>
                      <span class="badge badge-<?= $p['status'] === 'rejected' ? 'danger' : 'success' ?>">
                        <?= ucfirst(e($p['status'])) ?>
                      </span>
                    </td>
                    <td class="font-mono" style="font-size: 0.8rem;"><?= formatDate($p['updated_at']) ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div> 
<?php require_once __DIR__ . '/includes/footer.php'; ?>
