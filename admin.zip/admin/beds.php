<?php





declare(strict_types=1);
$required_role = 'admin';
require_once __DIR__ . '/includes/role_check.php';

$pdo = getDBConnection();

$selectedHostelId = (int)($_GET['hostel_id'] ?? 0);
$selectedStatus = trim($_GET['status'] ?? '');

$hostels = $pdo->query("SELECT id, name FROM hostels ORDER BY name ASC")->fetchAll();


$allRoomsStmt = $pdo->query("
    SELECT r.id, r.room_number, f.floor_number, bl.name as block_name, h.name as hostel_name
    FROM rooms r
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    JOIN hostels h ON bl.hostel_id = h.id
    ORDER BY h.name ASC, r.room_number ASC
");
$allRooms = $allRoomsStmt->fetchAll();


$bedSql = "
    SELECT 
        b.*,
        r.room_number,
        r.room_type,
        f.floor_number,
        bl.name as block_name,
        h.name as hostel_name,
        u.name as occupant_name,
        u.phone as occupant_phone
    FROM beds b
    JOIN rooms r ON b.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    JOIN hostels h ON bl.hostel_id = h.id
    LEFT JOIN seat_allocations sa ON sa.bed_id = b.id AND sa.status = 'active'
    LEFT JOIN boarders bo ON sa.boarder_id = bo.id
    LEFT JOIN users u ON bo.user_id = u.id
    WHERE 1=1
";

$params = [];
if ($selectedHostelId > 0) {
    $bedSql .= " AND h.id = :hid";
    $params['hid'] = $selectedHostelId;
}
if (!empty($selectedStatus)) {
    $bedSql .= " AND b.status = :st";
    $params['st'] = $selectedStatus;
}

$bedSql .= " ORDER BY h.id ASC, bl.id ASC, r.room_number ASC, b.bed_number ASC";

$stmt = $pdo->prepare($bedSql);
$stmt->execute($params);
$beds = $stmt->fetchAll();

$page_title = 'Bed Inventory';
$page_heading = 'Bed Inventory & Allocation Status';
$page_subheading = 'Real-time bed states and active occupants';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      <div class="table-toolbar">
        
        <div style="display: flex; gap: 0.75rem; flex-wrap: wrap;">
          <select class="form-control" style="width: auto;" onchange="applyFilters()" id="hostelFilter">
            <option value="0">All Hostels</option>
            <?php foreach ($hostels as $h): ?>
              <option value="<?= $h['id'] ?>" <?= $selectedHostelId === (int)$h['id'] ? 'selected' : '' ?>>
                <?= e($h['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>

          <select class="form-control" style="width: auto;" onchange="applyFilters()" id="statusFilter">
            <option value="">All Statuses</option>
            <option value="vacant" <?= $selectedStatus === 'vacant' ? 'selected' : '' ?>>Vacant</option>
            <option value="occupied" <?= $selectedStatus === 'occupied' ? 'selected' : '' ?>>Occupied</option>
            <option value="maintenance" <?= $selectedStatus === 'maintenance' ? 'selected' : '' ?>>Maintenance</option>
          </select>
        </div>

        <button class="btn btn-primary" onclick="openModal('addBedModal')">+ Add Bed to Room</button>
      </div>

      <div class="card">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Bed ID</th>
                <th>Hostel & Block</th>
                <th>Room & Floor</th>
                <th>Occupancy Status</th>
                <th>Current Occupant</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($beds)): ?>
                <?php foreach ($beds as $bed): ?>
                  <tr>
                    <td><strong><?= e($bed['bed_number']) ?></strong></td>
                    <td>
                      <div><?= e($bed['hostel_name']) ?></div>
                      <span style="font-size: 0.78rem; color: var(--text-muted);"><?= e($bed['block_name']) ?></span>
                    </td>
                    <td>
                      <strong><?= e($bed['room_number']) ?></strong>
                      <div style="font-size: 0.78rem; color: var(--text-muted);"><?= e($bed['floor_number']) ?></div>
                    </td>
                    <td>
                      <span class="badge badge-<?= e($bed['status']) ?>">
                        <?= ucfirst(e($bed['status'])) ?>
                      </span>
                    </td>
                    <td>
                      <?php if ($bed['status'] === 'occupied' && $bed['occupant_name']): ?>
                        <strong><?= e($bed['occupant_name']) ?></strong>
                        <div style="font-size: 0.78rem; color: var(--text-muted);"><?= e($bed['occupant_phone']) ?></div>
                      <?php elseif ($bed['status'] === 'maintenance'): ?>
                        <span style="color: var(--maintenance); font-size: 0.85rem; font-style: italic;">Under Maintenance</span>
                      <?php else: ?>
                        <span style="color: var(--success); font-size: 0.85rem;">Ready for Allocation</span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <div class="actions-cell">
                        <?php if ($bed['status'] !== 'occupied'): ?>
                          <form method="POST" action="<?= BASE_URL ?>/actions/bed.php" style="display: inline;">
                            <input type="hidden" name="action" value="toggle_maintenance">
                            <input type="hidden" name="bed_id" value="<?= $bed['id'] ?>">
                            <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                            <button type="submit" class="btn btn-secondary btn-sm">
                              <?= $bed['status'] === 'maintenance' ? 'Set Vacant' : 'Set Maint.' ?>
                            </button>
                          </form>
                        <?php endif; ?>

                        <form method="POST" action="<?= BASE_URL ?>/actions/bed.php" onsubmit="return confirm('Delete this bed record?');" style="display: inline;">
                          <input type="hidden" name="action" value="delete">
                          <input type="hidden" name="bed_id" value="<?= $bed['id'] ?>">
                          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                          <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="6" style="text-align: center; padding: 2rem;">No beds found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div> 

    
    <div class="modal-backdrop" id="addBedModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Add Bed to Room</h3>
          <button class="modal-close" onclick="closeModal('addBedModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/bed.php" data-validate="true">
          <input type="hidden" name="action" value="create">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Select Room <span class="required">*</span></label>
              <select name="room_id" class="form-control" required>
                <option value="">-- Choose Room --</option>
                <?php foreach ($allRooms as $rm): ?>
                  <option value="<?= $rm['id'] ?>">
                    <?= e($rm['hostel_name']) ?> &rsaquo; <?= e($rm['room_number']) ?> (<?= e($rm['floor_number']) ?>)
                  </option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Bed Code / Label <span class="required">*</span></label>
                <input type="text" name="bed_number" class="form-control" required placeholder="e.g. B3, Bed-A">
              </div>

              <div class="form-group">
                <label class="form-label">Initial Status</label>
                <select name="status" class="form-control">
                  <option value="vacant">Vacant</option>
                  <option value="maintenance">Maintenance</option>
                </select>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('addBedModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Add Bed</button>
          </div>
        </form>
      </div>
    </div>

  <script>
    function applyFilters() {
      const hid = document.getElementById('hostelFilter').value;
      const st = document.getElementById('statusFilter').value;
      const baseUrl = window.BASE_URL || '';
      location.href = `${baseUrl}/admin/beds.php?hostel_id=${hid}&status=${st}`;
    }
  </script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
