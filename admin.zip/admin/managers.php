<?php





declare(strict_types=1);
$required_role = 'admin';
require_once __DIR__ . '/includes/role_check.php';

$pdo = getDBConnection();


$stmt = $pdo->query("
    SELECT 
        u.*, 
        h.id as hostel_id, 
        h.name as hostel_name
    FROM users u
    LEFT JOIN manager_assignments ma ON ma.manager_id = u.id
    LEFT JOIN hostels h ON ma.hostel_id = h.id
    WHERE u.role = 'manager'
    ORDER BY u.id DESC
");
$managers = $stmt->fetchAll();


$hostels = $pdo->query("SELECT id, name FROM hostels ORDER BY name ASC")->fetchAll();

$page_title = 'Hostel Managers';
$page_heading = 'Hostel Managers';
$page_subheading = 'Manage hostel managers and residency assignments';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      <div class="table-toolbar">
        <div>
          <h3 style="font-size: 1.15rem; font-weight: 700;">Hostel Supervisors</h3>
          <p style="font-size: 0.82rem; color: var(--text-muted);">Managers have scoped administrative rights to their assigned residence hall</p>
        </div>
        <button class="btn btn-primary" onclick="openModal('addManagerModal')">
          + Add New Manager
        </button>
      </div>

      <div class="card">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Manager Name</th>
                <th>Contact Info</th>
                <th>Assigned Hostel</th>
                <th>Account Status</th>
                <th>Joined Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($managers)): ?>
                <?php foreach ($managers as $mgr): ?>
                  <tr>
                    <td>
                      <div style="display: flex; align-items: center; gap: 0.75rem;">
                        <div class="user-avatar" style="width: 32px; height: 32px; font-size: 0.8rem;">
                          <?= strtoupper(substr($mgr['name'], 0, 1)) ?>
                        </div>
                        <strong><?= e($mgr['name']) ?></strong>
                      </div>
                    </td>
                    <td>
                      <div><?= e($mgr['email']) ?></div>
                      <div style="font-size: 0.8rem; color: var(--text-muted);"><?= e($mgr['phone']) ?></div>
                    </td>
                    <td>
                      <?php if ($mgr['hostel_name']): ?>
                        <span class="badge badge-info"><?= e($mgr['hostel_name']) ?></span>
                      <?php else: ?>
                        <span class="badge badge-warning">Unassigned</span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <span class="badge badge-<?= $mgr['status'] === 'active' ? 'active' : 'rejected' ?>">
                        <?= ucfirst(e($mgr['status'])) ?>
                      </span>
                    </td>
                    <td class="font-mono" style="font-size: 0.8rem;"><?= formatDate($mgr['created_at']) ?></td>
                    <td>
                      <div class="actions-cell">
                        <button class="btn btn-secondary btn-sm" onclick='editManager(<?= json_encode($mgr) ?>)'>Edit</button>
                        
                        <form method="POST" action="<?= BASE_URL ?>/actions/manager.php" onsubmit="return confirm('Are you sure you want to remove this manager account?');" style="display: inline;">
                          <input type="hidden" name="action" value="delete">
                          <input type="hidden" name="manager_id" value="<?= $mgr['id'] ?>">
                          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                          <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="6" style="text-align: center; padding: 2rem; color: var(--text-muted);">No managers found.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div> 

    
    <div class="modal-backdrop" id="addManagerModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Add New Hostel Manager</h3>
          <button class="modal-close" onclick="closeModal('addManagerModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/manager.php" data-validate="true">
          <input type="hidden" name="action" value="create">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Full Name <span class="required">*</span></label>
              <input type="text" name="name" class="form-control" required placeholder="e.g. Tanvir Ahmed">
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Email Address <span class="required">*</span></label>
                <input type="email" name="email" class="form-control" required placeholder="manager@hostel.com">
              </div>
              <div class="form-group">
                <label class="form-label">Phone Number <span class="required">*</span></label>
                <input type="tel" name="phone" class="form-control" required placeholder="+8801XXXXXXXXX">
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Initial Password <span class="required">*</span></label>
              <input type="password" name="password" class="form-control" required placeholder="Minimum 6 characters">
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Assign to Residence Hall <span class="required">*</span></label>
                <select name="hostel_id" class="form-control" required>
                  <option value="">-- Choose Hostel --</option>
                  <?php foreach ($hostels as $h): ?>
                    <option value="<?= $h['id'] ?>"><?= e($h['name']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Account Status</label>
                <select name="status" class="form-control">
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('addManagerModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Create Manager</button>
          </div>
        </form>
      </div>
    </div>

    
    <div class="modal-backdrop" id="editManagerModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Edit Hostel Manager</h3>
          <button class="modal-close" onclick="closeModal('editManagerModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/manager.php" data-validate="true">
          <input type="hidden" name="action" value="update">
          <input type="hidden" name="manager_id" id="edit_manager_id">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Full Name <span class="required">*</span></label>
              <input type="text" name="name" id="edit_name" class="form-control" required>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Email (Read Only)</label>
                <input type="email" id="edit_email" class="form-control" readonly>
              </div>
              <div class="form-group">
                <label class="form-label">Phone Number <span class="required">*</span></label>
                <input type="tel" name="phone" id="edit_phone" class="form-control" required>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Reset Password (Leave blank to keep current)</label>
              <input type="password" name="password" class="form-control" placeholder="Optional new password">
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Assign to Residence Hall <span class="required">*</span></label>
                <select name="hostel_id" id="edit_hostel_id" class="form-control" required>
                  <?php foreach ($hostels as $h): ?>
                    <option value="<?= $h['id'] ?>"><?= e($h['name']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Account Status</label>
                <select name="status" id="edit_status" class="form-control">
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
            </div>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('editManagerModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Update Manager</button>
          </div>
        </form>
      </div>
    </div>

  <script>
    function editManager(mgr) {
      document.getElementById('edit_manager_id').value = mgr.id;
      document.getElementById('edit_name').value = mgr.name;
      document.getElementById('edit_email').value = mgr.email;
      document.getElementById('edit_phone').value = mgr.phone;
      document.getElementById('edit_hostel_id').value = mgr.hostel_id || '';
      document.getElementById('edit_status').value = mgr.status;
      openModal('editManagerModal');
    }
  </script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
