<?php






declare(strict_types=1);
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

if (!isLoggedIn() || !hasRole(['admin', 'manager'])) {
    die('Unauthorized access.');
}

$pdo = getDBConnection();
$selectedMonth = trim($_GET['month'] ?? date('Y-m'));
$selectedHostelId = (int)($_GET['hostel_id'] ?? 0);


$hostelName = 'All Residential Halls';
if ($selectedHostelId > 0) {
    $hStmt = $pdo->prepare("SELECT name FROM hostels WHERE id = ?");
    $hStmt->execute([$selectedHostelId]);
    $hostelName = $hStmt->fetchColumn() ?: 'All Hostels';
}


$billSql = "
    SELECT 
        COALESCE(SUM(b.total_amount), 0) as total_billed,
        COALESCE(SUM(b.paid_amount), 0) as total_collected,
        COALESCE(SUM(b.due_amount), 0) as total_due
    FROM bills b
    JOIN boarders bo ON b.boarder_id = bo.id
    JOIN seat_allocations sa ON sa.boarder_id = bo.id AND sa.status = 'active'
    JOIN beds bd ON sa.bed_id = bd.id
    JOIN rooms r ON bd.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE b.billing_month = :month
";
$params = ['month' => $selectedMonth];
if ($selectedHostelId > 0) {
    $billSql .= " AND bl.hostel_id = :hid";
    $params['hid'] = $selectedHostelId;
}
$bStmt = $pdo->prepare($billSql);
$bStmt->execute($params);
$summary = $bStmt->fetch();


$expSql = "SELECT COALESCE(SUM(amount), 0) FROM bazar_expenses WHERE DATE_FORMAT(expense_date, '%Y-%m') = :month";
$expParams = ['month' => $selectedMonth];
if ($selectedHostelId > 0) {
    $expSql .= " AND hostel_id = :hid";
    $expParams['hid'] = $selectedHostelId;
}
$eStmt = $pdo->prepare($expSql);
$eStmt->execute($expParams);
$totalExpense = (float)$eStmt->fetchColumn();

$netBalance = (float)$summary['total_collected'] - $totalExpense;


$listSql = "
    SELECT b.*, u.name as boarder_name, bo.student_id
    FROM bills b
    JOIN boarders bo ON b.boarder_id = bo.id
    JOIN users u ON bo.user_id = u.id
    LEFT JOIN seat_allocations sa ON sa.boarder_id = bo.id AND sa.status = 'active'
    LEFT JOIN beds bd ON sa.bed_id = bd.id
    LEFT JOIN rooms r ON bd.room_id = r.id
    LEFT JOIN floors f ON r.floor_id = f.id
    LEFT JOIN blocks bl ON f.block_id = bl.id
    WHERE b.billing_month = :month
";
if ($selectedHostelId > 0) {
    $listSql .= " AND bl.hostel_id = :hid";
}
$listSql .= " ORDER BY b.id ASC";

$lStmt = $pdo->prepare($listSql);
$lStmt->execute($params);
$bills = $lStmt->fetchAll();


ob_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Financial Audit Report - <?= e($selectedMonth) ?></title>
  <style>
    body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 11px; color: #1e293b; margin: 20px; line-height: 1.4; }
    .header { text-align: center; border-bottom: 2px solid #0d9488; padding-bottom: 12px; margin-bottom: 15px; }
    .header h1 { font-size: 18px; color: #0f172a; margin: 0 0 4px; text-transform: uppercase; }
    .header p { margin: 2px 0; color: #64748b; font-size: 11px; }
    .meta-box { background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; margin-bottom: 15px; border-radius: 4px; }
    .meta-table { width: 100%; }
    .meta-table td { padding: 3px 6px; }
    .summary-grid { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
    .summary-grid td { width: 25%; padding: 10px; border: 1px solid #cbd5e1; text-align: center; }
    .summary-grid .label { font-size: 9px; color: #64748b; text-transform: uppercase; font-weight: bold; }
    .summary-grid .val { font-size: 14px; font-weight: bold; color: #0d9488; margin-top: 4px; }
    .data-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
    .data-table th { background: #0f172a; color: #ffffff; padding: 6px; font-size: 10px; text-align: left; }
    .data-table td { padding: 6px; border-bottom: 1px solid #e2e8f0; font-size: 10px; }
    .data-table tr:nth-child(even) { background-color: #f8fafc; }
    .signatures { width: 100%; margin-top: 40px; }
    .signatures td { width: 50%; padding-top: 30px; }
    .sig-line { border-top: 1px solid #94a3b8; width: 180px; text-align: center; padding-top: 4px; font-size: 10px; color: #64748b; }
  </style>
</head>
<body>
  <div class="header">
    <h1>Hostel Seat & Mess Management System</h1>
    <p>Office of Student Residential Affairs | Official Financial Audit Ledger</p>
    <p><strong>Period:</strong> <?= formatDate($selectedMonth . '-01', 'F Y') ?> | <strong>Facility:</strong> <?= e($hostelName) ?></p>
  </div>

  <table class="summary-grid">
    <tr>
      <td>
        <div class="label">Total Billed</div>
        <div class="val"><?= formatCurrency($summary['total_billed']) ?></div>
      </td>
      <td>
        <div class="label">Total Collected</div>
        <div class="val" style="color: #10b981;"><?= formatCurrency($summary['total_collected']) ?></div>
      </td>
      <td>
        <div class="label">Mess Food Outlay</div>
        <div class="val" style="color: #ef4444;"><?= formatCurrency($totalExpense) ?></div>
      </td>
      <td>
        <div class="label">Net Cash Surplus</div>
        <div class="val" style="color: #0369a1;"><?= formatCurrency($netBalance) ?></div>
      </td>
    </tr>
  </table>

  <h3>Detailed Monthly Boarder Invoices</h3>
  <table class="data-table">
    <thead>
      <tr>
        <th>Bill ID</th>
        <th>Boarder Name</th>
        <th>Student ID</th>
        <th>Rent</th>
        <th>Meal Cost</th>
        <th>Other</th>
        <th>Total</th>
        <th>Paid</th>
        <th>Due</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($bills as $b): ?>
        <tr>
          <td>#<?= str_pad((string)$b['id'], 5, '0', STR_PAD_LEFT) ?></td>
          <td><strong><?= e($b['boarder_name']) ?></strong></td>
          <td><?= e($b['student_id']) ?></td>
          <td><?= formatCurrency($b['room_rent']) ?></td>
          <td><?= formatCurrency($b['meal_cost']) ?></td>
          <td><?= formatCurrency($b['other_charges']) ?></td>
          <td><strong><?= formatCurrency($b['total_amount']) ?></strong></td>
          <td><?= formatCurrency($b['paid_amount']) ?></td>
          <td><?= formatCurrency($b['due_amount']) ?></td>
          <td><?= strtoupper(e($b['status'])) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <table class="signatures">
    <tr>
      <td>
        <div class="sig-line">Prepared By (Hall Bursar)</div>
      </td>
      <td style="text-align: right;">
        <div class="sig-line" style="margin-left: auto;">Approved By (Super Admin)</div>
      </td>
    </tr>
  </table>
</body>
</html>
<?php
$html = ob_get_clean();

$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', false);

$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

$filename = "Financial_Report_{$selectedMonth}.pdf";
$dompdf->stream($filename, ["Attachment" => false]);
exit;
