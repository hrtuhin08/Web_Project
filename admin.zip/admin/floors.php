<?php





declare(strict_types=1);
$required_role = 'admin';
require_once __DIR__ . '/includes/role_check.php';

$pdo = getDBConnection();

$selectedHostelId = (int)($_GET['hostel_id'] ?? 0);


$hostels = $pdo->query("SELECT id, name FROM hostels ORDER BY name ASC")->fetchAll();


$blocksStmt = $pdo->query("
    SELECT bl.id, bl.name, h.name as hostel_name 
    FROM blocks bl 
    JOIN hostels h ON bl.hostel_id = h.id 
    ORDER BY h.name ASC, bl.name ASC
");
$allBlocks = $blocksStmt->fetchAll();


$floorsSql = "
    SELECT 
        f.id, 
        f.floor_number, 
        f.created_at,
        bl.name as block_name, 
        h.id as hostel_id,
        h.name as hostel_name,
        COUNT(DISTINCT r.id) as room_count,
        COUNT(DISTINCT b.id) as bed_count,
        SUM(CASE WHEN b.status = 'occupied' THEN 1 ELSE 0 END) as occupied_count
    FROM floors f
    JOIN blocks bl ON f.block_id = bl.id
    JOIN hostels h ON bl.hostel_id = h.id
    LEFT JOIN rooms r ON r.floor_id = f.id
    LEFT JOIN beds b ON b.room_id = r.id
";

$params = [];
if ($selectedHostelId > 0) {
    $floorsSql .= " WHERE h.id = :hid";
    $params['hid'] = $selectedHostelId;
}

$floorsSql .= " GROUP BY f.id, f.floor_number, f.created_at, bl.name, h.id, h.name ORDER BY h.name ASC, bl.name ASC, f.floor_number ASC";

$stmt = $pdo->prepare($floorsSql);
$stmt->execute($params);
$floors = $stmt->fetchAll();

$page_title = 'Floor Levels';
$page_heading = 'Floor Levels & Tier Configurations';
$page_subheading = 'Manage hostel floor levels, capacity distribution, and block mappings';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      <div class="table-toolbar">
        <div style="display: flex; align-items: center; gap: 0.75rem;">
          <label class="form-label" style="margin: 0;">Filter Hostel:</label>
          <select class="form-control" style="width: auto;" onchange="location.href='<?= BASE_URL ?>/admin/floors.php?hostel_id=' + this.value;">
            <option value="0">All Hostels</option>
            <?php foreach ($hostels as $h): ?>
              <option value="<?= $h['id'] ?>" <?= $selectedHostelId === (int)$h['id'] ? 'selected' : '' ?>>
                <?= e($h['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div style="display: flex; gap: 0.75rem;">
          <a href="<?= BASE_URL ?>/admin/rooms.php" class="btn btn-secondary">Manage Rooms &rarr;</a>
          <button class="btn btn-primary" onclick="openModal('addFloorModal')">+ Add Floor Level</button>
        </div>
      </div>

      <div class="card">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Floor Level</th>
                <th>Hostel Facility</th>
                <th>Block / Wing</th>
                <th>Rooms Count</th>
                <th>Total Bed Capacity</th>
                <th>Occupancy</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($floors)): ?>
                <?php foreach ($floors as $fl): ?>
                  <tr>
                    <td><strong><?= e($fl['floor_number']) ?></strong></td>
                    <td><?= e($fl['hostel_name']) ?></td>
                    <td><span class="badge badge-info"><?= e($fl['block_name']) ?></span></td>
                    <td class="font-mono"><?= (int)$fl['room_count'] ?> Rooms</td>
                    <td class="font-mono"><?= (int)$fl['bed_count'] ?> Beds</td>
                    <td>
                      <span class="font-mono" style="color: <?= $fl['occupied_count'] > 0 ? 'var(--danger)' : 'var(--text-muted)' ?>; font-weight: 700;">
                        <?= (int)$fl['occupied_count'] ?>
                      </span> / <?= (int)$fl['bed_count'] ?> Occupied
                    </td>
                    <td>
                      <form method="POST" action="<?= BASE_URL ?>/actions/floor.php" onsubmit="return confirm('Deleting this floor will remove all its rooms and beds. Continue?');" style="display: inline;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="floor_id" value="<?= $fl['id'] ?>">
                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="7" style="text-align: center; padding: 2rem;">No floor levels found matching filter.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div> 

    
    <div class="modal-backdrop" id="addFloorModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Add Floor Level</h3>
          <button class="modal-close" onclick="closeModal('addFloorModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/floor.php" data-validate="true">
          <input type="hidden" name="action" value="create">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Residential Block <span class="required">*</span></label>
              <select name="block_id" class="form-control" required>
                <option value="">-- Choose Target Block --</option>
                <?php foreach ($allBlocks as $b): ?>
                  <option value="<?= $b['id'] ?>"><?= e($b['hostel_name']) ?> &rsaquo; <?= e($b['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Floor Designation <span class="required">*</span></label>
              <input type="text" name="floor_number" class="form-control" required placeholder="e.g. 1st Floor, 2nd Floor, Ground Floor">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('addFloorModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Create Floor</button>
          </div>
        </form>
      </div>
    </div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
