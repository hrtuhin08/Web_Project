<?php





declare(strict_types=1);
$required_role = 'admin';
require_once __DIR__ . '/includes/role_check.php';

$pdo = getDBConnection();


$stmt = $pdo->query("
    SELECT 
        h.*,
        COUNT(DISTINCT bl.id) as block_count,
        COUNT(DISTINCT r.id) as room_count,
        COUNT(DISTINCT b.id) as bed_count,
        SUM(CASE WHEN b.status = 'occupied' THEN 1 ELSE 0 END) as occupied_count
    FROM hostels h
    LEFT JOIN blocks bl ON bl.hostel_id = h.id
    LEFT JOIN floors f ON f.block_id = bl.id
    LEFT JOIN rooms r ON r.floor_id = f.id
    LEFT JOIN beds b ON b.room_id = r.id
    GROUP BY h.id
    ORDER BY h.id ASC
");
$hostels = $stmt->fetchAll();


$blockStmt = $pdo->query("
    SELECT bl.*, h.name as hostel_name, COUNT(r.id) as room_count
    FROM blocks bl
    JOIN hostels h ON bl.hostel_id = h.id
    LEFT JOIN floors f ON f.block_id = bl.id
    LEFT JOIN rooms r ON r.floor_id = f.id
    GROUP BY bl.id
    ORDER BY h.id ASC, bl.id ASC
");
$blocks = $blockStmt->fetchAll();

$page_title = 'Hostels & Blocks';
$page_heading = 'Hostels & Residential Blocks';
$page_subheading = 'Manage hostel buildings, wings, and residential structures';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      <div class="table-toolbar">
        <div>
          <h3 style="font-size: 1.15rem; font-weight: 700;">Hostel Properties</h3>
          <p style="font-size: 0.82rem; color: var(--text-muted);">Main residence facilities registered in the system</p>
        </div>
        <div style="display: flex; gap: 0.75rem;">
          <button class="btn btn-secondary" onclick="openModal('addBlockModal')">+ Add Block</button>
          <button class="btn btn-primary" onclick="openModal('addHostelModal')">+ Add New Hostel</button>
        </div>
      </div>

      <div class="dashboard-grid-2" style="margin-bottom: 2.5rem;">
        <?php foreach ($hostels as $hostel): ?>
          <div class="card">
            <div class="card-header">
              <div>
                <h3 class="card-title"><?= e($hostel['name']) ?></h3>
                <p class="card-subtitle"><?= e($hostel['address']) ?></p>
              </div>
              <div class="actions-cell">
                <button class="btn btn-secondary btn-sm" onclick='editHostel(<?= json_encode($hostel) ?>)'>Edit</button>
                <form method="POST" action="<?= BASE_URL ?>/actions/hostel.php" onsubmit="return confirm('Deleting this hostel will remove all its blocks, rooms, and beds. Confirm delete?');">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="hostel_id" value="<?= $hostel['id'] ?>">
                  <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                  <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
              </div>
            </div>

            <p style="font-size: 0.88rem; color: var(--text-muted); margin-bottom: 1.25rem;">
              <?= e($hostel['description'] ?: 'Modern residential facility equipped with dining, study, and high-speed networking.') ?>
            </p>

            <div class="stats-grid" style="grid-template-columns: repeat(3, 1fr); gap: 0.75rem; margin-bottom: 0;">
              <div style="background: #f8fafc; padding: 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); text-align: center;">
                <div style="font-size: 0.75rem; color: var(--text-muted);">Blocks</div>
                <div class="font-mono" style="font-size: 1.3rem; font-weight: 700;"><?= $hostel['block_count'] ?></div>
              </div>
              <div style="background: #f8fafc; padding: 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); text-align: center;">
                <div style="font-size: 0.75rem; color: var(--text-muted);">Total Beds</div>
                <div class="font-mono" style="font-size: 1.3rem; font-weight: 700;"><?= $hostel['bed_count'] ?></div>
              </div>
              <div style="background: #f8fafc; padding: 0.75rem; border-radius: var(--radius-sm); border: 1px solid var(--border-color); text-align: center;">
                <div style="font-size: 0.75rem; color: var(--text-muted);">Occupancy</div>
                <div class="font-mono" style="font-size: 1.3rem; font-weight: 700; color: var(--primary);">
                  <?= $hostel['bed_count'] > 0 ? round(($hostel['occupied_count'] / $hostel['bed_count']) * 100) : 0 ?>%
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      
      <div class="card">
        <div class="card-header">
          <div>
            <h3 class="card-title">Residential Blocks & Wings</h3>
            <p class="card-subtitle">Sub-divisions containing floors and rooms</p>
          </div>
        </div>

        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Block Name</th>
                <th>Parent Hostel</th>
                <th>Total Rooms</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($blocks)): ?>
                <?php foreach ($blocks as $bl): ?>
                  <tr>
                    <td><strong><?= e($bl['name']) ?></strong></td>
                    <td><span class="badge badge-info"><?= e($bl['hostel_name']) ?></span></td>
                    <td class="font-mono"><?= (int)$bl['room_count'] ?> Rooms</td>
                    <td>
                      <form method="POST" action="<?= BASE_URL ?>/actions/block.php" onsubmit="return confirm('Delete this block and associated rooms?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="block_id" value="<?= $bl['id'] ?>">
                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="4" style="text-align: center; padding: 2rem;">No blocks configured.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div> 

    
    <div class="modal-backdrop" id="addHostelModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Add New Hostel</h3>
          <button class="modal-close" onclick="closeModal('addHostelModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/hostel.php" data-validate="true">
          <input type="hidden" name="action" value="create">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Hostel Name <span class="required">*</span></label>
              <input type="text" name="name" class="form-control" required placeholder="e.g. Padma Residence Hall">
            </div>
            <div class="form-group">
              <label class="form-label">Address Location <span class="required">*</span></label>
              <textarea name="address" class="form-control" rows="2" required placeholder="Street address or campus quadrant"></textarea>
            </div>
            <div class="form-group">
              <label class="form-label">Description & Notes</label>
              <textarea name="description" class="form-control" rows="2" placeholder="Brief summary of amenities, wing setup..."></textarea>
            </div>
            <div class="form-group">
              <label class="form-label">Target Bed Capacity</label>
              <input type="number" name="total_capacity" class="form-control" placeholder="e.g. 60" value="40">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('addHostelModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Save Hostel</button>
          </div>
        </form>
      </div>
    </div>

    
    <div class="modal-backdrop" id="editHostelModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Edit Hostel Property</h3>
          <button class="modal-close" onclick="closeModal('editHostelModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/hostel.php" data-validate="true">
          <input type="hidden" name="action" value="update">
          <input type="hidden" name="hostel_id" id="edit_hostel_id">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Hostel Name <span class="required">*</span></label>
              <input type="text" name="name" id="edit_h_name" class="form-control" required>
            </div>
            <div class="form-group">
              <label class="form-label">Address <span class="required">*</span></label>
              <textarea name="address" id="edit_h_address" class="form-control" rows="2" required></textarea>
            </div>
            <div class="form-group">
              <label class="form-label">Description</label>
              <textarea name="description" id="edit_h_desc" class="form-control" rows="2"></textarea>
            </div>
            <div class="form-group">
              <label class="form-label">Target Bed Capacity</label>
              <input type="number" name="total_capacity" id="edit_h_cap" class="form-control">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('editHostelModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Update Details</button>
          </div>
        </form>
      </div>
    </div>

    
    <div class="modal-backdrop" id="addBlockModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Add Residential Block</h3>
          <button class="modal-close" onclick="closeModal('addBlockModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/block.php" data-validate="true">
          <input type="hidden" name="action" value="create">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Hostel <span class="required">*</span></label>
              <select name="hostel_id" class="form-control" required>
                <?php foreach ($hostels as $h): ?>
                  <option value="<?= $h['id'] ?>"><?= e($h['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Block Name <span class="required">*</span></label>
              <input type="text" name="name" class="form-control" required placeholder="e.g. Block C (North Wing)">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('addBlockModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Add Block</button>
          </div>
        </form>
      </div>
    </div>

  <script>
    function editHostel(h) {
      document.getElementById('edit_hostel_id').value = h.id;
      document.getElementById('edit_h_name').value = h.name;
      document.getElementById('edit_h_address').value = h.address;
      document.getElementById('edit_h_desc').value = h.description || '';
      document.getElementById('edit_h_cap').value = h.total_capacity;
      openModal('editHostelModal');
    }
  </script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
