<?php





declare(strict_types=1);
$required_role = 'admin';
require_once __DIR__ . '/includes/role_check.php';

$pdo = getDBConnection();

$selectedHostelId = (int)($_GET['hostel_id'] ?? 0);


$hostels = $pdo->query("SELECT id, name FROM hostels ORDER BY name ASC")->fetchAll();


$blockSql = "
    SELECT 
        bl.*,
        h.id as hostel_id,
        h.name as hostel_name,
        COUNT(DISTINCT f.id) as floor_count,
        COUNT(DISTINCT r.id) as room_count,
        COUNT(DISTINCT b.id) as bed_count,
        SUM(CASE WHEN b.status = 'occupied' THEN 1 ELSE 0 END) as occupied_count
    FROM blocks bl
    JOIN hostels h ON bl.hostel_id = h.id
    LEFT JOIN floors f ON f.block_id = bl.id
    LEFT JOIN rooms r ON r.floor_id = f.id
    LEFT JOIN beds b ON b.room_id = r.id
";

$params = [];
if ($selectedHostelId > 0) {
    $blockSql .= " WHERE h.id = :hid";
    $params['hid'] = $selectedHostelId;
}

$blockSql .= " GROUP BY bl.id, bl.hostel_id, bl.name, bl.created_at, h.id, h.name ORDER BY h.name ASC, bl.name ASC";

$stmt = $pdo->prepare($blockSql);
$stmt->execute($params);
$blocks = $stmt->fetchAll();

$page_title = 'Hostel Blocks';
$page_heading = 'Residential Blocks & Wings';
$page_subheading = 'Manage building wings, residential divisions, and tier structures';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      <div class="table-toolbar">
        <div style="display: flex; align-items: center; gap: 0.75rem;">
          <label class="form-label" style="margin: 0;">Filter Hostel:</label>
          <select class="form-control" style="width: auto;" onchange="location.href='<?= BASE_URL ?>/admin/blocks.php?hostel_id=' + this.value;">
            <option value="0">All Hostels</option>
            <?php foreach ($hostels as $h): ?>
              <option value="<?= $h['id'] ?>" <?= $selectedHostelId === (int)$h['id'] ? 'selected' : '' ?>>
                <?= e($h['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div style="display: flex; gap: 0.75rem;">
          <a href="<?= BASE_URL ?>/admin/hostels.php" class="btn btn-secondary">&larr; Back to Hostels</a>
          <button class="btn btn-primary" onclick="openModal('addBlockModal')">+ Add New Block</button>
        </div>
      </div>

      <div class="card">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Block Name</th>
                <th>Hostel Facility</th>
                <th>Floors Count</th>
                <th>Rooms Count</th>
                <th>Bed Capacity</th>
                <th>Occupancy</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($blocks)): ?>
                <?php foreach ($blocks as $bl): ?>
                  <tr>
                    <td><strong><?= e($bl['name']) ?></strong></td>
                    <td><?= e($bl['hostel_name']) ?></td>
                    <td class="font-mono"><?= (int)$bl['floor_count'] ?> Floors</td>
                    <td class="font-mono"><?= (int)$bl['room_count'] ?> Rooms</td>
                    <td class="font-mono"><?= (int)$bl['bed_count'] ?> Beds</td>
                    <td>
                      <span class="font-mono" style="color: <?= $bl['occupied_count'] > 0 ? 'var(--danger)' : 'var(--text-muted)' ?>; font-weight: 700;">
                        <?= (int)$bl['occupied_count'] ?>
                      </span> / <?= (int)$bl['bed_count'] ?> Occupied
                    </td>
                    <td>
                      <form method="POST" action="<?= BASE_URL ?>/actions/block.php" onsubmit="return confirm('Deleting this block will cascade delete its floors, rooms, and beds. Continue?');" style="display: inline;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="block_id" value="<?= $bl['id'] ?>">
                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                      </form>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="7" style="text-align: center; padding: 2rem;">No blocks found matching filter.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div> 

    
    <div class="modal-backdrop" id="addBlockModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Add Residential Block</h3>
          <button class="modal-close" onclick="closeModal('addBlockModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/block.php" data-validate="true">
          <input type="hidden" name="action" value="create">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="form-group">
              <label class="form-label">Hostel Facility <span class="required">*</span></label>
              <select name="hostel_id" class="form-control" required>
                <option value="">-- Choose Target Hostel --</option>
                <?php foreach ($hostels as $h): ?>
                  <option value="<?= $h['id'] ?>"><?= e($h['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Block / Wing Name <span class="required">*</span></label>
              <input type="text" name="name" class="form-control" required placeholder="e.g. Block C (North Wing)">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('addBlockModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Save Block</button>
          </div>
        </form>
      </div>
    </div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
