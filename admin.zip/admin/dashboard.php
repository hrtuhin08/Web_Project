<?php





declare(strict_types=1);
$required_role = 'admin';
require_once __DIR__ . '/includes/role_check.php';

$pdo = getDBConnection();
$currentMonth = date('Y-m');


$totalHostels = (int)$pdo->query("SELECT COUNT(*) FROM hostels")->fetchColumn();
$totalRooms = (int)$pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
$totalBeds = (int)$pdo->query("SELECT COUNT(*) FROM beds")->fetchColumn();
$occupiedBeds = (int)$pdo->query("SELECT COUNT(*) FROM beds WHERE status = 'occupied'")->fetchColumn();
$vacantBeds = (int)$pdo->query("SELECT COUNT(*) FROM beds WHERE status = 'vacant'")->fetchColumn();
$maintenanceBeds = (int)$pdo->query("SELECT COUNT(*) FROM beds WHERE status = 'maintenance'")->fetchColumn();

$totalBoarders = (int)$pdo->query("SELECT COUNT(*) FROM boarders")->fetchColumn();
$pendingApprovals = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'boarder' AND status = 'pending'")->fetchColumn();


$revStmt = $pdo->prepare("SELECT COALESCE(SUM(paid_amount), 0) FROM bills WHERE billing_month = ?");
$revStmt->execute([$currentMonth]);
$monthlyRevenue = (float)$revStmt->fetchColumn();

$unpaidBills = (int)$pdo->query("SELECT COUNT(*) FROM bills WHERE status IN ('unpaid', 'partially_paid')")->fetchColumn();
$paidBills = (int)$pdo->query("SELECT COUNT(*) FROM bills WHERE status = 'paid'")->fetchColumn();
$partiallyPaidBills = (int)$pdo->query("SELECT COUNT(*) FROM bills WHERE status = 'partially_paid'")->fetchColumn();


$months = [];
$billedArr = [];
$collectedArr = [];

for ($i = 4; $i >= 0; $i--) {
    $m = date('Y-m', strtotime("-{$i} months"));
    $mLabel = date('M Y', strtotime("-{$i} months"));
    $months[] = $mLabel;

    $mStmt = $pdo->prepare("SELECT COALESCE(SUM(total_amount), 0) as billed, COALESCE(SUM(paid_amount), 0) as collected FROM bills WHERE billing_month = ?");
    $mStmt->execute([$m]);
    $mRow = $mStmt->fetch();
    $billedArr[] = (float)($mRow['billed'] ?? 0);
    $collectedArr[] = (float)($mRow['collected'] ?? 0);
}


$actStmt = $pdo->query("
    SELECT a.*, u.name as user_name, u.role as user_role 
    FROM activities a 
    LEFT JOIN users u ON a.user_id = u.id 
    ORDER BY a.created_at DESC 
    LIMIT 8
");
$recentActivities = $actStmt->fetchAll();

$page_title = 'System Overview';
$page_heading = 'Super Admin Overview';
$page_subheading = 'Comprehensive operational metrics & analytics';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Total Hostels</div>
            <div class="stat-value"><?= $totalHostels ?></div>
            <div class="stat-sub"><span><?= $totalRooms ?> Active Rooms</span></div>
          </div>
          <div class="stat-icon icon-teal">🏛️</div>
        </div>

        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Total Beds</div>
            <div class="stat-value"><?= $totalBeds ?></div>
            <div class="stat-sub"><span style="color: var(--success);"><?= $vacantBeds ?> Vacant</span> | <span style="color: var(--danger);"><?= $occupiedBeds ?> Occupied</span></div>
          </div>
          <div class="stat-icon icon-blue">🛏️</div>
        </div>

        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Total Boarders</div>
            <div class="stat-value"><?= $totalBoarders ?></div>
            <div class="stat-sub">
              <?php if ($pendingApprovals > 0): ?>
                <a href="<?= BASE_URL ?>/admin/approvals.php" style="color: #b45309; font-weight: 700;">⚠️ <?= $pendingApprovals ?> Approvals Pending</a>
              <?php else: ?>
                <span style="color: var(--success);">All accounts approved</span>
              <?php endif; ?>
            </div>
          </div>
          <div class="stat-icon icon-amber">🎓</div>
        </div>

        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Revenue (<?= date('M') ?>)</div>
            <div class="stat-value font-mono"><?= formatCurrency($monthlyRevenue) ?></div>
            <div class="stat-sub"><span><?= $unpaidBills ?> Unpaid / Due Bills</span></div>
          </div>
          <div class="stat-icon icon-green">💵</div>
        </div>
      </div>

      
      <div class="dashboard-grid-2">
        
        <div class="card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Billing & Collections Trend</h3>
              <p class="card-subtitle">Monthly billed dues versus verified collections</p>
            </div>
          </div>
          <div class="chart-wrapper">
            <canvas id="revenueChart" 
              data-months='<?= json_encode($months) ?>'
              data-billed='<?= json_encode($billedArr) ?>'
              data-collected='<?= json_encode($collectedArr) ?>'></canvas>
          </div>
        </div>

        
        <div class="card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Overall Bed Occupancy</h3>
              <p class="card-subtitle">Current status distribution across all residences</p>
            </div>
            <span class="badge badge-info"><?= $totalBeds ?> Total Capacity</span>
          </div>
          <div class="chart-wrapper">
            <canvas id="occupancyChart"
              data-occupied="<?= $occupiedBeds ?>"
              data-vacant="<?= $vacantBeds ?>"
              data-maintenance="<?= $maintenanceBeds ?>"></canvas>
          </div>
        </div>
      </div>

      
      <div class="card">
        <div class="card-header">
          <div>
            <h3 class="card-title">Live System Activities</h3>
            <p class="card-subtitle">Chronological audit trail of admin, manager, and boarder operations</p>
          </div>
        </div>

        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Timestamp</th>
                <th>Operator</th>
                <th>Role</th>
                <th>Action</th>
                <th>Details</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($recentActivities)): ?>
                <?php foreach ($recentActivities as $act): ?>
                  <tr>
                    <td class="font-mono" style="font-size: 0.8rem; color: var(--text-muted);">
                      <?= formatDate($act['created_at'], 'M d, H:i') ?>
                    </td>
                    <td><strong><?= e($act['user_name'] ?? 'System') ?></strong></td>
                    <td>
                      <span class="badge badge-<?= $act['user_role'] === 'admin' ? 'danger' : 'info' ?>">
                        <?= e($act['user_role'] ?? 'cron') ?>
                      </span>
                    </td>
                    <td><strong><?= e($act['action']) ?></strong></td>
                    <td style="color: var(--text-muted); font-size: 0.85rem;"><?= e($act['details']) ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="5" style="text-align: center; padding: 2rem; color: var(--text-muted);">No activity records found.</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div> 
<?php require_once __DIR__ . '/includes/footer.php'; ?>
