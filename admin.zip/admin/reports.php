<?php





declare(strict_types=1);
$required_role = 'admin';
require_once __DIR__ . '/includes/role_check.php';

$pdo = getDBConnection();

$selectedMonth = trim($_GET['month'] ?? date('Y-m')); 
$selectedHostelId = (int)($_GET['hostel_id'] ?? 0);

$hostels = $pdo->query("SELECT id, name FROM hostels ORDER BY name ASC")->fetchAll();


$billSql = "
    SELECT 
        COALESCE(SUM(b.total_amount), 0) as total_billed,
        COALESCE(SUM(b.paid_amount), 0) as total_collected,
        COALESCE(SUM(b.due_amount), 0) as total_due
    FROM bills b
    JOIN boarders bo ON b.boarder_id = bo.id
    JOIN seat_allocations sa ON sa.boarder_id = bo.id AND sa.status = 'active'
    JOIN beds bd ON sa.bed_id = bd.id
    JOIN rooms r ON bd.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE b.billing_month = :month
";
$billParams = ['month' => $selectedMonth];
if ($selectedHostelId > 0) {
    $billSql .= " AND bl.hostel_id = :hid";
    $billParams['hid'] = $selectedHostelId;
}
$bStmt = $pdo->prepare($billSql);
$bStmt->execute($billParams);
$billSummary = $bStmt->fetch();


$expSql = "SELECT COALESCE(SUM(amount), 0) as total_expense FROM bazar_expenses WHERE DATE_FORMAT(expense_date, '%Y-%m') = :month";
$expParams = ['month' => $selectedMonth];
if ($selectedHostelId > 0) {
    $expSql .= " AND hostel_id = :hid";
    $expParams['hid'] = $selectedHostelId;
}
$eStmt = $pdo->prepare($expSql);
$eStmt->execute($expParams);
$totalExpense = (float)$eStmt->fetchColumn();

$netSurplus = (float)$billSummary['total_collected'] - $totalExpense;


$billsListSql = "
    SELECT b.*, u.name as boarder_name, bo.student_id, h.name as hostel_name
    FROM bills b
    JOIN boarders bo ON b.boarder_id = bo.id
    JOIN users u ON bo.user_id = u.id
    LEFT JOIN seat_allocations sa ON sa.boarder_id = bo.id AND sa.status = 'active'
    LEFT JOIN beds bd ON sa.bed_id = bd.id
    LEFT JOIN rooms r ON bd.room_id = r.id
    LEFT JOIN floors f ON r.floor_id = f.id
    LEFT JOIN blocks bl ON f.block_id = bl.id
    LEFT JOIN hostels h ON bl.hostel_id = h.id
    WHERE b.billing_month = :month
";
if ($selectedHostelId > 0) {
    $billsListSql .= " AND bl.hostel_id = :hid";
}
$billsListSql .= " ORDER BY b.id DESC";

$blStmt = $pdo->prepare($billsListSql);
$blStmt->execute($billParams);
$detailedBills = $blStmt->fetchAll();

$page_title = 'Financial Reports';
$page_heading = 'Financial & Billing Audit Reports';
$page_subheading = 'Revenue, collection rates, bazar food expenditures, and PDF export';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      
      <div class="table-toolbar">
        <form method="GET" action="<?= BASE_URL ?>/admin/reports.php" style="display: flex; gap: 0.75rem; flex-wrap: wrap; align-items: center;">
          <input type="month" name="month" class="form-control" style="width: auto;" value="<?= e($selectedMonth) ?>">

          <select name="hostel_id" class="form-control" style="width: auto;">
            <option value="0">All Hostels</option>
            <?php foreach ($hostels as $h): ?>
              <option value="<?= $h['id'] ?>" <?= $selectedHostelId === (int)$h['id'] ? 'selected' : '' ?>>
                <?= e($h['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>

          <button type="submit" class="btn btn-secondary">Filter</button>
        </form>

        <a href="<?= BASE_URL ?>/admin/financial_report_pdf.php?month=<?= urlencode($selectedMonth) ?>&hostel_id=<?= $selectedHostelId ?>" 
           target="_blank" 
           class="btn btn-primary">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
          Export Financial PDF Report
        </a>
      </div>

      
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Total Invoiced</div>
            <div class="stat-value font-mono"><?= formatCurrency($billSummary['total_billed']) ?></div>
            <div class="stat-sub"><span>Month: <?= formatDate($selectedMonth . '-01', 'M Y') ?></span></div>
          </div>
          <div class="stat-icon icon-teal">📄</div>
        </div>

        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Collected Inflow</div>
            <div class="stat-value font-mono" style="color: var(--success);"><?= formatCurrency($billSummary['total_collected']) ?></div>
            <div class="stat-sub"><span style="color: var(--danger);"><?= formatCurrency($billSummary['total_due']) ?> Due/Pending</span></div>
          </div>
          <div class="stat-icon icon-green">💰</div>
        </div>

        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Mess Food Outflow</div>
            <div class="stat-value font-mono" style="color: var(--danger);"><?= formatCurrency($totalExpense) ?></div>
            <div class="stat-sub"><span>Bazar groceries & fuel</span></div>
          </div>
          <div class="stat-icon icon-rose">🛒</div>
        </div>

        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Net Surplus / Cash</div>
            <div class="stat-value font-mono" style="color: <?= $netSurplus >= 0 ? 'var(--success)' : 'var(--danger)' ?>;">
              <?= formatCurrency($netSurplus) ?>
            </div>
            <div class="stat-sub"><span>Collected vs Mess Outlay</span></div>
          </div>
          <div class="stat-icon icon-blue">📊</div>
        </div>
      </div>

      
      <div class="card">
        <div class="card-header">
          <div>
            <h3 class="card-title">Billing Ledger & Payment Verification</h3>
            <p class="card-subtitle">Month: <?= formatDate($selectedMonth . '-01', 'F Y') ?></p>
          </div>
        </div>

        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Bill #</th>
                <th>Boarder</th>
                <th>Student ID</th>
                <th>Hostel</th>
                <th>Room Rent</th>
                <th>Meal Cost</th>
                <th>Other</th>
                <th>Total</th>
                <th>Paid</th>
                <th>Due</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($detailedBills)): ?>
                <?php foreach ($detailedBills as $b): ?>
                  <tr>
                    <td class="font-mono">#<?= str_pad((string)$b['id'], 5, '0', STR_PAD_LEFT) ?></td>
                    <td><strong><?= e($b['boarder_name']) ?></strong></td>
                    <td class="font-mono"><?= e($b['student_id']) ?></td>
                    <td><?= e($b['hostel_name'] ?? 'Padma') ?></td>
                    <td class="font-mono"><?= formatCurrency($b['room_rent']) ?></td>
                    <td class="font-mono"><?= formatCurrency($b['meal_cost']) ?></td>
                    <td class="font-mono"><?= formatCurrency($b['other_charges']) ?></td>
                    <td class="font-mono"><strong><?= formatCurrency($b['total_amount']) ?></strong></td>
                    <td class="font-mono" style="color: var(--success);"><?= formatCurrency($b['paid_amount']) ?></td>
                    <td class="font-mono" style="color: var(--danger);"><?= formatCurrency($b['due_amount']) ?></td>
                    <td>
                      <span class="badge badge-<?= e($b['status']) ?>">
                        <?= ucfirst(str_replace('_', ' ', e($b['status']))) ?>
                      </span>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="11" style="text-align: center; padding: 2rem;">No bills on record for this filter.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div> 
<?php require_once __DIR__ . '/includes/footer.php'; ?>
