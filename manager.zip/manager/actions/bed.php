<?php





declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !hasRole(['admin', 'manager'])) {
    setFlash('error', 'Unauthorized.');
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user = currentUser();
$pdo = getDBConnection();
$action = $_POST['action'] ?? '';
$csrfToken = $_POST['csrf_token'] ?? '';

if (!verifyCSRFToken($csrfToken)) {
    setFlash('error', 'Security token invalid.');
    header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/admin/beds.php')));
    exit;
}

if ($action === 'create') {
    $roomId = (int)($_POST['room_id'] ?? 0);
    $bedNumber = trim($_POST['bed_number'] ?? '');
    $status = $_POST['status'] ?? 'vacant';

    if ($roomId > 0 && !empty($bedNumber)) {
        $stmt = $pdo->prepare("INSERT INTO beds (room_id, bed_number, status, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->execute([$roomId, $bedNumber, $status]);
        logActivity((int)$user['id'], 'Created Bed', "Added bed {$bedNumber} in room ID {$roomId}");
        setFlash('success', 'Bed created successfully.');
    } else {
        setFlash('error', 'Room and Bed Number are required.');
    }
} elseif ($action === 'toggle_maintenance') {
    $bedId = (int)($_POST['bed_id'] ?? 0);
    if ($bedId > 0) {
        $check = $pdo->prepare("SELECT status FROM beds WHERE id = ?");
        $check->execute([$bedId]);
        $currStatus = $check->fetchColumn();

        if ($currStatus === 'occupied') {
            setFlash('error', 'Cannot set an occupied bed to maintenance. Vacate or transfer boarder first.');
        } else {
            $newStatus = ($currStatus === 'maintenance') ? 'vacant' : 'maintenance';
            $up = $pdo->prepare("UPDATE beds SET status = ? WHERE id = ?");
            $up->execute([$newStatus, $bedId]);
            logActivity((int)$user['id'], 'Toggled Bed Status', "Bed ID {$bedId} set to {$newStatus}");
            setFlash('success', "Bed marked as {$newStatus}.");
        }
    }
} elseif ($action === 'delete') {
    $bedId = (int)($_POST['bed_id'] ?? 0);
    if ($bedId > 0) {
        $pdo->prepare("DELETE FROM beds WHERE id = ?")->execute([$bedId]);
        logActivity((int)$user['id'], 'Deleted Bed', "Deleted bed ID {$bedId}");
        setFlash('success', 'Bed removed.');
    }
}

header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/admin/beds.php')));
exit;
