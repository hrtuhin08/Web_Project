<?php





declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !hasRole(['admin', 'manager'])) {
    setFlash('error', 'Unauthorized.');
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user = currentUser();
$pdo = getDBConnection();
$action = $_POST['action'] ?? '';
$csrfToken = $_POST['csrf_token'] ?? '';

if (!verifyCSRFToken($csrfToken)) {
    setFlash('error', 'Security token expired.');
    header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/manager/bills.php')));
    exit;
}

if ($action === 'generate_monthly_batch') {
    $hostelId = (int)($_POST['hostel_id'] ?? 0);
    $billingMonth = trim($_POST['billing_month'] ?? date('Y-m')); 
    $otherCharges = (float)($_POST['other_charges'] ?? 200.00);

    if ($hostelId <= 0 || empty($billingMonth)) {
        setFlash('error', 'Please specify a hostel and billing month.');
        header('Location: ' . BASE_URL . '/manager/bills.php');
        exit;
    }

    $mealRate = calculatePerMealCost($hostelId, $billingMonth);

    
    $stmt = $pdo->prepare("
        SELECT 
            b.id AS boarder_id,
            r.rent AS room_rent,
            u.name AS boarder_name
        FROM seat_allocations sa
        JOIN boarders b ON sa.boarder_id = b.id
        JOIN users u ON b.user_id = u.id
        JOIN beds bd ON sa.bed_id = bd.id
        JOIN rooms r ON bd.room_id = r.id
        JOIN floors f ON r.floor_id = f.id
        JOIN blocks bl ON f.block_id = bl.id
        WHERE bl.hostel_id = ? AND sa.status = 'active'
    ");
    $stmt->execute([$hostelId]);
    $activeBoarders = $stmt->fetchAll();

    $generatedCount = 0;
    $skippedCount = 0;

    foreach ($activeBoarders as $ab) {
        $boarderId = (int)$ab['boarder_id'];

        
        $checkDup = $pdo->prepare("SELECT id FROM bills WHERE boarder_id = ? AND billing_month = ?");
        $checkDup->execute([$boarderId, $billingMonth]);
        if ($checkDup->fetch()) {
            $skippedCount++;
            continue;
        }

        
        $mStmt = $pdo->prepare("
            SELECT 
                COALESCE(SUM(breakfast), 0) + 
                COALESCE(SUM(lunch), 0) + 
                COALESCE(SUM(dinner), 0) AS total_meals
            FROM meal_preferences
            WHERE boarder_id = ? AND DATE_FORMAT(meal_date, '%Y-%m') = ?
        ");
        $mStmt->execute([$boarderId, $billingMonth]);
        $totalMeals = (int)($mStmt->fetchColumn() ?: 0);

        $roomRent = (float)$ab['room_rent'];
        $mealCost = round($totalMeals * $mealRate, 2);
        $discount = 0.00;
        $totalAmount = $roomRent + $mealCost + $otherCharges - $discount;
        $paidAmount = 0.00;
        $dueAmount = $totalAmount;
        $status = 'unpaid';

        $insBill = $pdo->prepare("
            INSERT INTO bills (boarder_id, billing_month, room_rent, meal_cost, other_charges, discount, total_amount, paid_amount, due_amount, status, generated_by, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $insBill->execute([$boarderId, $billingMonth, $roomRent, $mealCost, $otherCharges, $discount, $totalAmount, $paidAmount, $dueAmount, $status, $user['id']]);
        $generatedCount++;
    }

    logActivity((int)$user['id'], 'Generated Batch Bills', "Generated {$generatedCount} bills for month {$billingMonth} (Skipped {$skippedCount} existing)");
    setFlash('success', "Billing run complete: {$generatedCount} bills created, {$skippedCount} skipped (already billed).");

} elseif ($action === 'record_offline_payment') {
    $billId = (int)($_POST['bill_id'] ?? 0);
    $amount = (float)($_POST['amount'] ?? 0);
    $method = $_POST['payment_method'] ?? 'Cash';
    $trxId = trim($_POST['transaction_id'] ?? ('TRX-' . strtoupper(bin2hex(random_bytes(4)))));

    if ($billId <= 0 || $amount <= 0) {
        setFlash('error', 'Please provide a valid bill ID and payment amount.');
        header('Location: ' . BASE_URL . '/manager/bills.php');
        exit;
    }

    try {
        $pdo->beginTransaction();

        $bStmt = $pdo->prepare("SELECT * FROM bills WHERE id = ? FOR UPDATE");
        $bStmt->execute([$billId]);
        $bill = $bStmt->fetch();

        if (!$bill) {
            $pdo->rollBack();
            setFlash('error', 'Bill not found.');
            header('Location: ' . BASE_URL . '/manager/bills.php');
            exit;
        }

        $boarderId = (int)$bill['boarder_id'];
        $newPaid = (float)$bill['paid_amount'] + $amount;
        $newDue = max(0.0, (float)$bill['total_amount'] - $newPaid);
        $newStatus = ($newDue <= 0) ? 'paid' : 'partially_paid';

        
        $pStmt = $pdo->prepare("
            INSERT INTO payments (bill_id, boarder_id, amount, payment_method, transaction_id, payment_date, received_by)
            VALUES (?, ?, ?, ?, ?, NOW(), ?)
        ");
        $pStmt->execute([$billId, $boarderId, $amount, $method, $trxId, $user['id']]);

        
        $uStmt = $pdo->prepare("UPDATE bills SET paid_amount = ?, due_amount = ?, status = ? WHERE id = ?");
        $uStmt->execute([$newPaid, $newDue, $newStatus, $billId]);

        logActivity((int)$user['id'], 'Recorded Payment', "Recorded payment of {$amount} for Bill ID {$billId}");

        $pdo->commit();
        setFlash('success', 'Payment recorded successfully.');
    } catch (Exception $e) {
        $pdo->rollBack();
        setFlash('error', 'Payment recording failed: ' . $e->getMessage());
    }
}

header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/manager/bills.php')));
exit;
