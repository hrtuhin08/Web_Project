<?php






declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !hasRole(['admin', 'manager'])) {
    setFlash('error', 'Unauthorized access.');
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user = currentUser();
$pdo = getDBConnection();
$action = $_POST['action'] ?? '';
$csrfToken = $_POST['csrf_token'] ?? '';

if (!verifyCSRFToken($csrfToken)) {
    setFlash('error', 'Security verification failed.');
    header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/manager/seat_map.php')));
    exit;
}

if ($action === 'allocate') {
    $boarderId = (int)($_POST['boarder_id'] ?? 0);
    $bedId = (int)($_POST['bed_id'] ?? 0);
    $allocDate = $_POST['allocation_date'] ?? date('Y-m-d');

    if ($boarderId <= 0 || $bedId <= 0) {
        setFlash('error', 'Please select both an eligible boarder and a bed.');
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/manager/seat_map.php')));
        exit;
    }

    try {
        $pdo->beginTransaction();

        
        $bCheck = $pdo->prepare("SELECT b.id, u.name, u.status, u.id as user_id FROM boarders b JOIN users u ON b.user_id = u.id WHERE b.id = ?");
        $bCheck->execute([$boarderId]);
        $boarder = $bCheck->fetch();

        if (!$boarder || !in_array($boarder['status'], ['approved', 'active'], true)) {
            $pdo->rollBack();
            setFlash('error', 'Boarder must be approved by the administrator before receiving a seat.');
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/manager/seat_map.php')));
            exit;
        }

        
        $existAlloc = $pdo->prepare("SELECT id FROM seat_allocations WHERE boarder_id = ? AND status = 'active'");
        $existAlloc->execute([$boarderId]);
        if ($existAlloc->fetch()) {
            $pdo->rollBack();
            setFlash('error', 'This boarder already has an active bed allocation. Use Transfer instead.');
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/manager/seat_map.php')));
            exit;
        }

        
        $bedCheck = $pdo->prepare("SELECT status, bed_number FROM beds WHERE id = ? FOR UPDATE");
        $bedCheck->execute([$bedId]);
        $bed = $bedCheck->fetch();

        if (!$bed || $bed['status'] !== 'vacant') {
            $pdo->rollBack();
            setFlash('error', 'Selected bed is not vacant or is under maintenance.');
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/manager/seat_map.php')));
            exit;
        }

        
        $insAlloc = $pdo->prepare("
            INSERT INTO seat_allocations (boarder_id, bed_id, allocated_by, allocation_date, status)
            VALUES (?, ?, ?, ?, 'active')
        ");
        $insAlloc->execute([$boarderId, $bedId, $user['id'], $allocDate]);

        $upBed = $pdo->prepare("UPDATE beds SET status = 'occupied' WHERE id = ?");
        $upBed->execute([$bedId]);

        $upUser = $pdo->prepare("UPDATE users SET status = 'active' WHERE id = ?");
        $upUser->execute([$boarder['user_id']]);

        logActivity((int)$user['id'], 'Seat Allocated', "Allocated bed {$bed['bed_number']} to {$boarder['name']}");

        $pdo->commit();
        setFlash('success', "Bed {$bed['bed_number']} allocated to {$boarder['name']} successfully.");
    } catch (Exception $e) {
        $pdo->rollBack();
        setFlash('error', 'Allocation failed: ' . $e->getMessage());
    }

} elseif ($action === 'transfer') {
    $boarderId = (int)($_POST['boarder_id'] ?? 0);
    $newBedId = (int)($_POST['new_bed_id'] ?? 0);

    if ($boarderId <= 0 || $newBedId <= 0) {
        setFlash('error', 'Invalid transfer request.');
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/manager/seat_map.php')));
        exit;
    }

    try {
        $pdo->beginTransaction();

        
        $currStmt = $pdo->prepare("SELECT id, bed_id FROM seat_allocations WHERE boarder_id = ? AND status = 'active' FOR UPDATE");
        $currStmt->execute([$boarderId]);
        $currAlloc = $currStmt->fetch();

        if (!$currAlloc) {
            $pdo->rollBack();
            setFlash('error', 'Boarder has no active bed allocation to transfer from.');
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/manager/seat_map.php')));
            exit;
        }

        
        $newBedStmt = $pdo->prepare("SELECT status, bed_number FROM beds WHERE id = ? FOR UPDATE");
        $newBedStmt->execute([$newBedId]);
        $newBed = $newBedStmt->fetch();

        if (!$newBed || $newBed['status'] !== 'vacant') {
            $pdo->rollBack();
            setFlash('error', 'Target bed is not vacant.');
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/manager/seat_map.php')));
            exit;
        }

        
        $pdo->prepare("UPDATE beds SET status = 'vacant' WHERE id = ?")->execute([$currAlloc['bed_id']]);
        $pdo->prepare("UPDATE seat_allocations SET status = 'transferred', end_date = CURDATE() WHERE id = ?")->execute([$currAlloc['id']]);

        
        $pdo->prepare("UPDATE beds SET status = 'occupied' WHERE id = ?")->execute([$newBedId]);
        $pdo->prepare("INSERT INTO seat_allocations (boarder_id, bed_id, allocated_by, allocation_date, status) VALUES (?, ?, ?, CURDATE(), 'active')")
            ->execute([$boarderId, $newBedId, $user['id']]);

        logActivity((int)$user['id'], 'Seat Transferred', "Transferred boarder ID {$boarderId} to bed {$newBed['bed_number']}");

        $pdo->commit();
        setFlash('success', 'Boarder successfully transferred to new bed.');
    } catch (Exception $e) {
        $pdo->rollBack();
        setFlash('error', 'Transfer failed: ' . $e->getMessage());
    }

} elseif ($action === 'vacate') {
    $allocationId = (int)($_POST['allocation_id'] ?? 0);

    if ($allocationId <= 0) {
        setFlash('error', 'Invalid allocation selection.');
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/manager/seat_map.php')));
        exit;
    }

    try {
        $pdo->beginTransaction();

        $allocStmt = $pdo->prepare("SELECT id, bed_id, boarder_id FROM seat_allocations WHERE id = ? FOR UPDATE");
        $allocStmt->execute([$allocationId]);
        $alloc = $allocStmt->fetch();

        if ($alloc) {
            $pdo->prepare("UPDATE seat_allocations SET status = 'vacated', end_date = CURDATE() WHERE id = ?")->execute([$allocationId]);
            $pdo->prepare("UPDATE beds SET status = 'vacant' WHERE id = ?")->execute([$alloc['bed_id']]);

            logActivity((int)$user['id'], 'Seat Vacated', "Vacated allocation ID {$allocationId}");
            $pdo->commit();
            setFlash('success', 'Bed vacated and returned to vacant inventory.');
        } else {
            $pdo->rollBack();
            setFlash('error', 'Allocation not found.');
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        setFlash('error', 'Failed to vacate bed.');
    }
}

header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/manager/seat_map.php')));
exit;
