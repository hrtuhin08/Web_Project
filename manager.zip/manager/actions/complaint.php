<?php





declare(strict_types=1);
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn()) {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user = currentUser();
$pdo = getDBConnection();
$action = $_POST['action'] ?? '';
$csrfToken = $_POST['csrf_token'] ?? '';

if (!verifyCSRFToken($csrfToken)) {
    setFlash('error', 'Security verification failed.');
    header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/')));
    exit;
}

if ($action === 'submit_complaint' && $user['role'] === 'boarder') {
    $category = $_POST['category'] ?? 'Other';
    $description = trim($_POST['description'] ?? '');

    $categories = ['Electrical', 'Plumbing', 'Internet', 'Furniture', 'Cleaning', 'Security', 'Other'];
    if (!in_array($category, $categories, true) || empty($description)) {
        setFlash('error', 'Please select a valid category and provide details.');
    } else {
        
        $stmt = $pdo->prepare("
            SELECT b.id as boarder_id, bl.hostel_id
            FROM boarders b
            LEFT JOIN seat_allocations sa ON sa.boarder_id = b.id AND sa.status = 'active'
            LEFT JOIN beds bd ON sa.bed_id = bd.id
            LEFT JOIN rooms r ON bd.room_id = r.id
            LEFT JOIN floors f ON r.floor_id = f.id
            LEFT JOIN blocks bl ON f.block_id = bl.id
            WHERE b.user_id = ?
        ");
        $stmt->execute([$user['id']]);
        $row = $stmt->fetch();

        if ($row) {
            $hostelId = $row['hostel_id'] ?: 1; 
            $ins = $pdo->prepare("
                INSERT INTO complaints (boarder_id, hostel_id, category, description, status, created_at)
                VALUES (?, ?, ?, ?, 'Pending', NOW())
            ");
            $ins->execute([$row['boarder_id'], $hostelId, $category, $description]);
            logActivity((int)$user['id'], 'Submitted Complaint', "Submitted {$category} complaint.");
            setFlash('success', 'Your complaint has been submitted. The hostel manager will inspect it shortly.');
        } else {
            setFlash('error', 'Boarder profile not found.');
        }
    }
} elseif ($action === 'update_status' && in_array($user['role'], ['manager', 'admin'], true)) {
    $complaintId = (int)($_POST['complaint_id'] ?? 0);
    $status = $_POST['status'] ?? 'Pending';
    $responseNote = trim($_POST['response_note'] ?? '');

    if ($complaintId > 0 && in_array($status, ['Pending', 'In Progress', 'Resolved'], true)) {
        $up = $pdo->prepare("UPDATE complaints SET status = ?, response_note = ?, updated_at = NOW() WHERE id = ?");
        $up->execute([$status, $responseNote, $complaintId]);
        logActivity((int)$user['id'], 'Updated Complaint', "Updated complaint ID {$complaintId} status to {$status}");
        setFlash('success', "Complaint marked as {$status}.");
    }
}

header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? (BASE_URL . '/')));
exit;
