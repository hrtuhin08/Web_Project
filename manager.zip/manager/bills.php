<?php





declare(strict_types=1);
$required_role = 'manager';
require_once __DIR__ . '/includes/role_check.php';

$user = currentUser();
$pdo = getDBConnection();

$hStmt = $pdo->prepare("SELECT h.* FROM manager_assignments ma JOIN hostels h ON ma.hostel_id = h.id WHERE ma.manager_id = ? LIMIT 1");
$hStmt->execute([$user['id']]);
$assignedHostel = $hStmt->fetch() ?: $pdo->query("SELECT * FROM hostels ORDER BY id ASC LIMIT 1")->fetch();
$hostelId = (int)$assignedHostel['id'];

$selectedMonth = trim($_GET['month'] ?? date('Y-m'));
$selectedStatus = trim($_GET['status'] ?? '');

$billSql = "
    SELECT 
        b.*,
        u.name as boarder_name,
        bo.student_id,
        r.room_number,
        bd.bed_number
    FROM bills b
    JOIN boarders bo ON b.boarder_id = bo.id
    JOIN users u ON bo.user_id = u.id
    JOIN seat_allocations sa ON sa.boarder_id = bo.id AND sa.status = 'active'
    JOIN beds bd ON sa.bed_id = bd.id
    JOIN rooms r ON bd.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE bl.hostel_id = :hid
";

$params = ['hid' => $hostelId];
if (!empty($selectedMonth)) {
    $billSql .= " AND b.billing_month = :month";
    $params['month'] = $selectedMonth;
}
if (!empty($selectedStatus)) {
    $billSql .= " AND b.status = :st";
    $params['st'] = $selectedStatus;
}

$billSql .= " ORDER BY b.id DESC";

$stmt = $pdo->prepare($billSql);
$stmt->execute($params);
$bills = $stmt->fetchAll();

$page_title = 'Monthly Bills';
$page_heading = 'Monthly Billing & Collections';
$page_subheading = e($assignedHostel['name']) . ' - Manage resident monthly dues and payment verification';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      <div class="table-toolbar">
        <form method="GET" action="<?= BASE_URL ?>/manager/bills.php" style="display: flex; gap: 0.75rem; flex-wrap: wrap; align-items: center;">
          <input type="month" name="month" class="form-control" style="width: auto;" value="<?= e($selectedMonth) ?>">
          
          <select name="status" class="form-control" style="width: auto;">
            <option value="">All Statuses</option>
            <option value="unpaid" <?= $selectedStatus === 'unpaid' ? 'selected' : '' ?>>Unpaid</option>
            <option value="partially_paid" <?= $selectedStatus === 'partially_paid' ? 'selected' : '' ?>>Partially Paid</option>
            <option value="paid" <?= $selectedStatus === 'paid' ? 'selected' : '' ?>>Paid</option>
          </select>

          <button type="submit" class="btn btn-secondary">Filter</button>
        </form>

        <button class="btn btn-primary" onclick="openModal('generateBatchModal')">
          ⚡ Run Monthly Batch Billing
        </button>
      </div>

      <div class="card">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Invoice #</th>
                <th>Boarder</th>
                <th>Room & Bed</th>
                <th>Month</th>
                <th>Rent</th>
                <th>Meal Cost</th>
                <th>Total</th>
                <th>Paid</th>
                <th>Due</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($bills)): ?>
                <?php foreach ($bills as $bill): ?>
                  <tr>
                    <td class="font-mono">#<?= str_pad((string)$bill['id'], 5, '0', STR_PAD_LEFT) ?></td>
                    <td>
                      <strong><?= e($bill['boarder_name']) ?></strong>
                      <div style="font-size: 0.78rem; color: var(--text-muted);"><?= e($bill['student_id']) ?></div>
                    </td>
                    <td><?= e($bill['room_number']) ?> - <?= e($bill['bed_number']) ?></td>
                    <td class="font-mono"><?= formatDate($bill['billing_month'] . '-01', 'M Y') ?></td>
                    <td class="font-mono"><?= formatCurrency($bill['room_rent']) ?></td>
                    <td class="font-mono"><?= formatCurrency($bill['meal_cost']) ?></td>
                    <td class="font-mono"><strong><?= formatCurrency($bill['total_amount']) ?></strong></td>
                    <td class="font-mono" style="color: var(--success);"><?= formatCurrency($bill['paid_amount']) ?></td>
                    <td class="font-mono" style="color: var(--danger); font-weight: 700;"><?= formatCurrency($bill['due_amount']) ?></td>
                    <td>
                      <span class="badge badge-<?= e($bill['status']) ?>">
                        <?= ucfirst(str_replace('_', ' ', e($bill['status']))) ?>
                      </span>
                    </td>
                    <td>
                      <?php if ((float)$bill['due_amount'] > 0): ?>
                        <button class="btn btn-success btn-sm" onclick='openPaymentModal(<?= json_encode($bill) ?>)'>
                          Record Payment
                        </button>
                      <?php else: ?>
                        <span style="color: var(--success); font-size: 0.8rem; font-weight: 600;">Settled</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="11" style="text-align: center; padding: 2rem;">No bills found matching query.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div> 

    
    <div class="modal-backdrop" id="generateBatchModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Generate Monthly Batch Bills</h3>
          <button class="modal-close" onclick="closeModal('generateBatchModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/bill.php" data-validate="true">
          <input type="hidden" name="action" value="generate_monthly_batch">
          <input type="hidden" name="hostel_id" value="<?= $hostelId ?>">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="alert alert-info">
              Generating invoices for all active boarders in <strong><?= e($assignedHostel['name']) ?></strong>. System automatically checks for duplicate bills and computes meal cost based on consumed meals!
            </div>

            <div class="form-group">
              <label class="form-label">Billing Month <span class="required">*</span></label>
              <input type="month" name="billing_month" class="form-control" required value="<?= date('Y-m') ?>">
            </div>

            <div class="form-group">
              <label class="form-label">Utility & General Maintenance Fee (BDT)</label>
              <input type="number" name="other_charges" class="form-control" value="200" step="10">
              <span class="form-hint">Standard fixed amenity fee applied to all residents.</span>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('generateBatchModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Generate Bills Now</button>
          </div>
        </form>
      </div>
    </div>

    
    <div class="modal-backdrop" id="paymentModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Record Offline Payment</h3>
          <button class="modal-close" onclick="closeModal('paymentModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/bill.php" data-validate="true">
          <input type="hidden" name="action" value="record_offline_payment">
          <input type="hidden" name="bill_id" id="pay_bill_id">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="alert alert-info">
              Invoice #<span id="pay_invoice_no"></span> &bull; Resident: <strong id="pay_boarder_name"></strong>
              <div style="margin-top: 0.3rem;">Outstanding Due: <span id="pay_due_val" class="font-mono" style="font-weight: 700; color: var(--danger);"></span></div>
            </div>

            <div class="form-group">
              <label class="form-label">Amount Received (BDT) <span class="required">*</span></label>
              <input type="number" step="0.5" name="amount" id="pay_amount" class="form-control" required>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label">Payment Method</label>
                <select name="payment_method" class="form-control">
                  <option value="Cash">Cash at Hall Desk</option>
                  <option value="bKash">bKash Merchant</option>
                  <option value="Nagad">Nagad</option>
                  <option value="Bank">Bank Deposit</option>
                </select>
              </div>

              <div class="form-group">
                <label class="form-label">Transaction / Voucher Ref #</label>
                <input type="text" name="transaction_id" class="form-control" placeholder="Optional reference">
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('paymentModal')">Cancel</button>
            <button type="submit" class="btn btn-success">Record Payment</button>
          </div>
        </form>
      </div>
    </div>

  <script>
    function openPaymentModal(b) {
      document.getElementById('pay_bill_id').value = b.id;
      document.getElementById('pay_invoice_no').textContent = String(b.id).padStart(5, '0');
      document.getElementById('pay_boarder_name').textContent = b.boarder_name;
      document.getElementById('pay_due_val').textContent = '৳ ' + parseFloat(b.due_amount).toFixed(2);
      document.getElementById('pay_amount').value = parseFloat(b.due_amount).toFixed(2);
      openModal('paymentModal');
    }
  </script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
