<?php





declare(strict_types=1);
$required_role = 'manager';
require_once __DIR__ . '/includes/role_check.php';

$user = currentUser();
$pdo = getDBConnection();

$hStmt = $pdo->prepare("SELECT h.* FROM manager_assignments ma JOIN hostels h ON ma.hostel_id = h.id WHERE ma.manager_id = ? LIMIT 1");
$hStmt->execute([$user['id']]);
$assignedHostel = $hStmt->fetch() ?: $pdo->query("SELECT * FROM hostels ORDER BY id ASC LIMIT 1")->fetch();
$hostelId = (int)$assignedHostel['id'];


$convStmt = $pdo->prepare("
    SELECT 
        c.id as conversation_id,
        c.updated_at,
        u.id as other_user_id,
        u.name as other_user_name,
        u.role as other_user_role,
        (SELECT message FROM messages WHERE conversation_id = c.id ORDER BY id DESC LIMIT 1) as last_message,
        (SELECT created_at FROM messages WHERE conversation_id = c.id ORDER BY id DESC LIMIT 1) as last_time,
        (SELECT COUNT(*) FROM messages WHERE conversation_id = c.id AND sender_id != ? AND is_read = 0) as unread_count
    FROM conversations c
    JOIN users u ON (u.id = CASE WHEN c.user_one_id = ? THEN c.user_two_id ELSE c.user_one_id END)
    WHERE c.user_one_id = ? OR c.user_two_id = ?
    ORDER BY c.updated_at DESC
");
$convStmt->execute([$user['id'], $user['id'], $user['id'], $user['id']]);
$conversations = $convStmt->fetchAll();


$activeConvId = (int)($_GET['conversation_id'] ?? 0);
if ($activeConvId <= 0 && !empty($conversations)) {
    $activeConvId = (int)$conversations[0]['conversation_id'];
}

$activeOtherUser = null;
$messages = [];

if ($activeConvId > 0) {
    
    $verifyStmt = $pdo->prepare("
        SELECT c.*, u.id as other_user_id, u.name as other_user_name, u.role as other_user_role, u.phone
        FROM conversations c
        JOIN users u ON (u.id = CASE WHEN c.user_one_id = ? THEN c.user_two_id ELSE c.user_one_id END)
        WHERE c.id = ? AND (c.user_one_id = ? OR c.user_two_id = ?)
    ");
    $verifyStmt->execute([$user['id'], $activeConvId, $user['id'], $user['id']]);
    $activeOtherUser = $verifyStmt->fetch();

    if ($activeOtherUser) {
        
        $msgStmt = $pdo->prepare("
            SELECT * FROM messages 
            WHERE conversation_id = ? 
            ORDER BY id ASC
        ");
        $msgStmt->execute([$activeConvId]);
        $messages = $msgStmt->fetchAll();

        
        $pdo->prepare("UPDATE messages SET is_read = 1 WHERE conversation_id = ? AND sender_id != ?")->execute([$activeConvId, $user['id']]);
    }
}


$hostelBoardersStmt = $pdo->prepare("
    SELECT u.id as user_id, u.name, b.student_id, r.room_number, bd.bed_number
    FROM seat_allocations sa
    JOIN boarders b ON sa.boarder_id = b.id
    JOIN users u ON b.user_id = u.id
    JOIN beds bd ON sa.bed_id = bd.id
    JOIN rooms r ON bd.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE bl.hostel_id = ? AND sa.status = 'active'
    ORDER BY u.name ASC
");
$hostelBoardersStmt->execute([$hostelId]);
$hostelBoarders = $hostelBoardersStmt->fetchAll();

$page_title = 'Resident Chat';
$page_heading = 'Live Resident & Staff Communication';
$page_subheading = 'Real-time AJAX messaging with hostel residents and mess staff';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      <div class="chat-app">
        
        <div class="chat-sidebar">
          <div class="chat-search-header" style="display: flex; justify-content: space-between; align-items: center;">
            <strong style="font-size: 0.95rem;">Conversations</strong>
            <button class="btn btn-primary btn-sm" onclick="openModal('newChatModal')">+ New Chat</button>
          </div>

          <div class="chat-users-list">
            <?php if (!empty($conversations)): ?>
              <?php foreach ($conversations as $c): ?>
                <a href="<?= BASE_URL ?>/manager/chat.php?conversation_id=<?= $c['conversation_id'] ?>" 
                   class="chat-user-item <?= (int)$c['conversation_id'] === $activeConvId ? 'active' : '' ?>">
                  <div class="user-avatar" style="width: 40px; height: 40px;">
                    <?= strtoupper(substr($c['other_user_name'], 0, 1)) ?>
                  </div>
                  <div class="chat-user-details">
                    <div class="chat-user-top">
                      <span class="chat-user-name"><?= e($c['other_user_name']) ?></span>
                      <span class="chat-user-time"><?= $c['last_time'] ? timeAgo($c['last_time']) : '' ?></span>
                    </div>
                    <div class="chat-last-msg">
                      <?= e($c['last_message'] ?: 'No messages yet') ?>
                    </div>
                  </div>
                  <?php if ((int)$c['unread_count'] > 0): ?>
                    <span class="nav-badge" style="margin-left: 0.35rem;"><?= $c['unread_count'] ?></span>
                  <?php endif; ?>
                </a>
              <?php endforeach; ?>
            <?php else: ?>
              <div style="padding: 2rem 1rem; text-align: center; color: var(--text-muted); font-size: 0.85rem;">
                No conversations yet. Start a new chat with a resident.
              </div>
            <?php endif; ?>
          </div>
        </div>

        
        <div class="chat-conversation-panel">
          <?php if ($activeOtherUser): ?>
            <div class="chat-header">
              <div style="display: flex; align-items: center; gap: 0.75rem;">
                <div class="user-avatar" style="width: 36px; height: 36px;">
                  <?= strtoupper(substr($activeOtherUser['other_user_name'], 0, 1)) ?>
                </div>
                <div>
                  <h4 style="font-size: 0.95rem; margin-bottom: 0.1rem;"><?= e($activeOtherUser['other_user_name']) ?></h4>
                  <span style="font-size: 0.75rem; color: var(--text-muted); text-transform: capitalize;">
                    <?= e($activeOtherUser['other_user_role']) ?> &bull; <?= e($activeOtherUser['phone']) ?>
                  </span>
                </div>
              </div>
            </div>

            <div class="chat-messages-container" id="chatMessagesContainer">
              <?php foreach ($messages as $msg): ?>
                <?php $isSent = (int)$msg['sender_id'] === (int)$user['id']; ?>
                <div class="chat-bubble <?= $isSent ? 'sent' : 'received' ?>" data-msg-id="<?= $msg['id'] ?>">
                  <div class="bubble-text"><?= e($msg['message']) ?></div>
                  <div class="bubble-meta"><?= timeAgo($msg['created_at']) ?></div>
                </div>
              <?php endforeach; ?>
            </div>

            
            <input type="hidden" id="activeConversationId" value="<?= $activeConvId ?>">
            <input type="hidden" id="currentUserId" value="<?= $user['id'] ?>">

            <form class="chat-input-bar" id="chatForm">
              <input type="text" id="chatMessageInput" placeholder="Type a message to <?= e($activeOtherUser['other_user_name']) ?>..." required autocomplete="off">
              <button type="submit" class="btn btn-primary" style="border-radius: var(--radius-full); padding: 0.65rem 1.25rem;">
                Send
              </button>
            </form>

          <?php else: ?>
            <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; color: var(--text-muted);">
              <div style="font-size: 3rem; margin-bottom: 0.5rem;">💬</div>
              <h4>Select or start a conversation</h4>
              <p style="font-size: 0.85rem;">Communicate directly with registered hall residents</p>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div> 

    
    <div class="modal-backdrop" id="newChatModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Start Conversation with Resident</h3>
          <button class="modal-close" onclick="closeModal('newChatModal')">&times;</button>
        </div>
        <div class="modal-body" style="max-height: 400px; overflow-y: auto;">
          <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 1rem;">
            Select any resident boarder in <?= e($assignedHostel['name']) ?> to initiate messaging:
          </p>
          <div style="display: flex; flex-direction: column; gap: 0.5rem;">
            <?php foreach ($hostelBoarders as $hb): ?>
              <div style="display: flex; align-items: center; justify-content: space-between; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: var(--radius-md);">
                <div>
                  <strong><?= e($hb['name']) ?></strong> (ID: <?= e($hb['student_id']) ?>)
                  <div style="font-size: 0.78rem; color: var(--text-muted);">Room <?= e($hb['room_number']) ?> - Bed <?= e($hb['bed_number']) ?></div>
                </div>
                <a href="<?= BASE_URL ?>/actions/message.php?action=start_or_get_conversation&target_user_id=<?= $hb['user_id'] ?>" class="btn btn-primary btn-sm">
                  Message
                </a>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" onclick="closeModal('newChatModal')">Close</button>
        </div>
      </div>
    </div>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
