<?php





declare(strict_types=1);
$required_role = 'manager';
require_once __DIR__ . '/includes/role_check.php';

$user = currentUser();
$pdo = getDBConnection();


$hStmt = $pdo->prepare("SELECT h.* FROM manager_assignments ma JOIN hostels h ON ma.hostel_id = h.id WHERE ma.manager_id = ? LIMIT 1");
$hStmt->execute([$user['id']]);
$assignedHostel = $hStmt->fetch() ?: $pdo->query("SELECT * FROM hostels ORDER BY id ASC LIMIT 1")->fetch();
$hostelId = (int)$assignedHostel['id'];


$roomsStmt = $pdo->prepare("
    SELECT r.*, f.floor_number, bl.name as block_name 
    FROM rooms r
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE bl.hostel_id = ?
    ORDER BY bl.name ASC, f.floor_number ASC, r.room_number ASC
");
$roomsStmt->execute([$hostelId]);
$rooms = $roomsStmt->fetchAll();


$bedsStmt = $pdo->prepare("
    SELECT 
        b.*,
        sa.id as allocation_id,
        sa.allocation_date,
        bo.id as boarder_id,
        bo.student_id,
        u.name as occupant_name,
        u.phone as occupant_phone
    FROM beds b
    JOIN rooms r ON b.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    LEFT JOIN seat_allocations sa ON sa.bed_id = b.id AND sa.status = 'active'
    LEFT JOIN boarders bo ON sa.boarder_id = bo.id
    LEFT JOIN users u ON bo.user_id = u.id
    WHERE bl.hostel_id = ?
    ORDER BY b.bed_number ASC
");
$bedsStmt->execute([$hostelId]);
$allBeds = $bedsStmt->fetchAll();


$bedsByRoom = [];
foreach ($allBeds as $bed) {
    $bedsByRoom[$bed['room_id']][] = $bed;
}


$eligibleBoardersStmt = $pdo->query("
    SELECT b.id as boarder_id, b.student_id, u.name as boarder_name, b.department
    FROM boarders b
    JOIN users u ON b.user_id = u.id
    WHERE u.status IN ('approved', 'active')
      AND b.id NOT IN (SELECT boarder_id FROM seat_allocations WHERE status = 'active')
    ORDER BY u.name ASC
");
$eligibleBoarders = $eligibleBoardersStmt->fetchAll();


$vacantBedsStmt = $pdo->prepare("
    SELECT b.id as bed_id, b.bed_number, r.room_number, f.floor_number, bl.name as block_name
    FROM beds b
    JOIN rooms r ON b.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE bl.hostel_id = ? AND b.status = 'vacant'
    ORDER BY r.room_number ASC, b.bed_number ASC
");
$vacantBedsStmt->execute([$hostelId]);
$vacantBeds = $vacantBedsStmt->fetchAll();

$page_title = 'Visual Seat Map';
$page_heading = 'Interactive Visual Seat Map';
$page_subheading = e($assignedHostel['name']) . ' - Room and bed allocation visualizer';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      
      <div class="seat-map-controls">
        <div class="seat-legend">
          <div class="legend-item">
            <span class="legend-dot" style="background-color: var(--success);"></span>
            <span>Vacant Bed</span>
          </div>
          <div class="legend-item">
            <span class="legend-dot" style="background-color: var(--danger);"></span>
            <span>Occupied</span>
          </div>
          <div class="legend-item">
            <span class="legend-dot" style="background-color: var(--maintenance);"></span>
            <span>Maintenance</span>
          </div>
        </div>

        <div style="display: flex; gap: 0.75rem;">
          <a href="<?= BASE_URL ?>/manager/allocate_seat.php" class="btn btn-primary btn-sm">+ Allocate Seat Form</a>
        </div>
      </div>

      
      <div class="rooms-grid">
        <?php foreach ($rooms as $room): ?>
          <?php $roomBeds = $bedsByRoom[$room['id']] ?? []; ?>
          <div class="room-card">
            <div class="room-header">
              <div>
                <h4 class="room-title"><?= e($room['room_number']) ?></h4>
                <div style="font-size: 0.75rem; color: var(--text-muted);"><?= e($room['block_name']) ?> &bull; <?= e($room['floor_number']) ?></div>
              </div>
              <div style="text-align: right;">
                <span class="badge badge-info" style="font-size: 0.7rem;"><?= ucfirst(e($room['room_type'])) ?></span>
                <div class="font-mono" style="font-size: 0.8rem; font-weight: 700; margin-top: 0.2rem;"><?= formatCurrency($room['rent']) ?></div>
              </div>
            </div>

            
            <div class="beds-container">
              <?php if (!empty($roomBeds)): ?>
                <?php foreach ($roomBeds as $bed): ?>
                  <div class="bed-box <?= e($bed['status']) ?>">
                    <div class="bed-top">
                      <span><?= e($bed['bed_number']) ?></span>
                      <span class="badge badge-<?= e($bed['status']) ?>" style="font-size: 0.65rem; padding: 0.1rem 0.4rem;">
                        <?= ucfirst(e($bed['status'])) ?>
                      </span>
                    </div>

                    <?php if ($bed['status'] === 'occupied' && $bed['occupant_name']): ?>
                      <div class="bed-occupant" title="<?= e($bed['occupant_name']) ?>">
                        👤 <?= e($bed['occupant_name']) ?>
                      </div>
                      <div style="font-size: 0.72rem; color: var(--text-muted); margin-bottom: 0.5rem;" class="font-mono">
                        ID: <?= e($bed['student_id']) ?>
                      </div>
                      <div class="bed-actions">
                        <button class="btn btn-secondary btn-sm" style="font-size: 0.7rem; padding: 0.2rem 0.45rem;"
                          onclick='openTransferModal(<?= $bed['boarder_id'] ?>, "<?= addslashes($bed['occupant_name']) ?>", "<?= $bed['bed_number'] ?>")'>
                          Transfer
                        </button>

                        <form method="POST" action="<?= BASE_URL ?>/actions/seat.php" onsubmit="return confirm('Vacate <?= addslashes($bed['occupant_name']) ?> from bed <?= $bed['bed_number'] ?>?');" style="display: inline;">
                          <input type="hidden" name="action" value="vacate">
                          <input type="hidden" name="allocation_id" value="<?= $bed['allocation_id'] ?>">
                          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                          <button type="submit" class="btn btn-danger btn-sm" style="font-size: 0.7rem; padding: 0.2rem 0.45rem;">
                            Vacate
                          </button>
                        </form>
                      </div>

                    <?php elseif ($bed['status'] === 'maintenance'): ?>
                      <div style="font-size: 0.75rem; color: var(--maintenance); margin: 0.5rem 0; font-style: italic;">
                        Under Maintenance
                      </div>
                      <div class="bed-actions">
                        <form method="POST" action="<?= BASE_URL ?>/actions/bed.php">
                          <input type="hidden" name="action" value="toggle_maintenance">
                          <input type="hidden" name="bed_id" value="<?= $bed['id'] ?>">
                          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                          <button type="submit" class="btn btn-secondary btn-sm" style="font-size: 0.7rem; padding: 0.2rem 0.45rem;">
                            Set Vacant
                          </button>
                        </form>
                      </div>

                    <?php else: ?>
                      <div style="font-size: 0.75rem; color: var(--success); margin: 0.5rem 0; font-weight: 600;">
                        Available
                      </div>
                      <div class="bed-actions">
                        <button class="btn btn-primary btn-sm" style="font-size: 0.7rem; padding: 0.2rem 0.45rem;"
                          onclick='openAssignModal(<?= $bed['id'] ?>, "<?= $room['room_number'] ?>", "<?= $bed['bed_number'] ?>")'>
                          Assign
                        </button>
                        <form method="POST" action="<?= BASE_URL ?>/actions/bed.php">
                          <input type="hidden" name="action" value="toggle_maintenance">
                          <input type="hidden" name="bed_id" value="<?= $bed['id'] ?>">
                          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                          <button type="submit" class="btn btn-secondary btn-sm" style="font-size: 0.7rem; padding: 0.2rem 0.45rem;" title="Maintenance">
                            Maint.
                          </button>
                        </form>
                      </div>
                    <?php endif; ?>
                  </div>
                <?php endforeach; ?>
              <?php else: ?>
                <div style="grid-column: 1 / -1; padding: 1rem; text-align: center; color: var(--text-muted); font-size: 0.8rem;">
                  No beds mapped yet.
                </div>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div> 

    
    <div class="modal-backdrop" id="assignModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Assign Bed to Approved Boarder</h3>
          <button class="modal-close" onclick="closeModal('assignModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/seat.php" data-validate="true">
          <input type="hidden" name="action" value="allocate">
          <input type="hidden" name="bed_id" id="assign_bed_id">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="alert alert-info">
              Target Bed: <strong id="assign_bed_label"></strong>
            </div>

            <div class="form-group">
              <label class="form-label">Select Approved Student <span class="required">*</span></label>
              <select name="boarder_id" class="form-control" required>
                <option value="">-- Choose Approved Boarder --</option>
                <?php if (!empty($eligibleBoarders)): ?>
                  <?php foreach ($eligibleBoarders as $eb): ?>
                    <option value="<?= $eb['boarder_id'] ?>">
                      <?= e($eb['boarder_name']) ?> (ID: <?= e($eb['student_id']) ?> - <?= e($eb['department']) ?>)
                    </option>
                  <?php endforeach; ?>
                <?php else: ?>
                  <option value="" disabled>No approved unallocated students currently available.</option>
                <?php endif; ?>
              </select>
              <span class="form-hint">Only approved students without an active seat are shown.</span>
            </div>

            <div class="form-group">
              <label class="form-label">Allocation Effective Date <span class="required">*</span></label>
              <input type="date" name="allocation_date" class="form-control" required value="<?= date('Y-m-d') ?>">
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('assignModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Confirm Allocation</button>
          </div>
        </form>
      </div>
    </div>

    
    <div class="modal-backdrop" id="transferModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Transfer Boarder to Vacant Bed</h3>
          <button class="modal-close" onclick="closeModal('transferModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/seat.php" data-validate="true">
          <input type="hidden" name="action" value="transfer">
          <input type="hidden" name="boarder_id" id="transfer_boarder_id">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="alert alert-warning">
              Boarder: <strong id="transfer_boarder_name"></strong> (Current Bed: <span id="transfer_current_bed"></span>)
            </div>

            <div class="form-group">
              <label class="form-label">Select New Vacant Bed <span class="required">*</span></label>
              <select name="new_bed_id" class="form-control" required>
                <option value="">-- Choose Vacant Destination Bed --</option>
                <?php if (!empty($vacantBeds)): ?>
                  <?php foreach ($vacantBeds as $vb): ?>
                    <option value="<?= $vb['bed_id'] ?>">
                      <?= e($vb['room_number']) ?> &rsaquo; <?= e($vb['bed_number']) ?> (<?= e($vb['block_name']) ?>, <?= e($vb['floor_number']) ?>)
                    </option>
                  <?php endforeach; ?>
                <?php else: ?>
                  <option value="" disabled>No vacant beds currently available in this hostel.</option>
                <?php endif; ?>
              </select>
              <span class="form-hint">Old bed will automatically become vacant upon transfer.</span>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('transferModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Complete Transfer</button>
          </div>
        </form>
      </div>
    </div>

  <script>
    function openAssignModal(bedId, roomNo, bedNo) {
      document.getElementById('assign_bed_id').value = bedId;
      document.getElementById('assign_bed_label').textContent = `${roomNo} - ${bedNo}`;
      openModal('assignModal');
    }

    function openTransferModal(boarderId, name, bedNo) {
      document.getElementById('transfer_boarder_id').value = boarderId;
      document.getElementById('transfer_boarder_name').textContent = name;
      document.getElementById('transfer_current_bed').textContent = bedNo;
      openModal('transferModal');
    }
  </script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
