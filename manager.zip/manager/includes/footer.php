<?php





declare(strict_types=1);
require_once __DIR__ . '/functions.php';

$flash = getFlash();
?>
      </div> 
    </main> 
  </div> 

  
  <div class="toast-container" id="toastContainer"></div>

  
  <script src="<?= BASE_URL ?>/assets/js/main.js"></script>
  <script src="<?= BASE_URL ?>/assets/js/validation.js"></script>
  <script src="<?= BASE_URL ?>/assets/js/dashboard.js"></script>
  <script src="<?= BASE_URL ?>/assets/js/meals.js"></script>
  <script src="<?= BASE_URL ?>/assets/js/chat.js"></script>

  <?php if ($flash): ?>
    <script>
      document.addEventListener('DOMContentLoaded', () => {
        showToast('<?= $flash['type'] ?>', '<?= addslashes($flash['message']) ?>');
      });
    </script>
  <?php endif; ?>
</body>
</html>
