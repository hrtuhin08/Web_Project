<?php





declare(strict_types=1);

require_once __DIR__ . '/functions.php';

if (!isLoggedIn()) {
    setFlash('error', 'Please log in to access the system.');
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$user = currentUser();
if ($user && $user['status'] !== 'active') {
    if ($user['status'] === 'pending') {
        setFlash('warning', 'Your registration is currently pending admin approval. You will receive access once approved.');
    } else {
        setFlash('error', 'Your account has been deactivated or rejected. Please contact the administrator.');
    }
    
    $_SESSION = [];
    if (session_id()) session_destroy();
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}
