<?php
declare(strict_types=1);
require_once __DIR__ . '/auth_check.php';
if (isset($required_role)) {
    $roles = is_array($required_role) ? $required_role : [$required_role];
    $user = currentUser();
    if (!$user || !in_array($user['role'], $roles, true)) {
        if ($user) { header('Location: ' . BASE_URL . '/dashboard.php'); } else { header('Location: ' . BASE_URL . '/login.php'); }
        exit;
    }
}
