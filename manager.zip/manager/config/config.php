<?php





declare(strict_types=1);


if (!defined('BASE_URL')) {
    define('BASE_URL', '/manager');
}
