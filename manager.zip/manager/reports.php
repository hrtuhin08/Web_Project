<?php





declare(strict_types=1);
$required_role = 'manager';
require_once __DIR__ . '/includes/role_check.php';

$user = currentUser();
$pdo = getDBConnection();

$hStmt = $pdo->prepare("SELECT h.* FROM manager_assignments ma JOIN hostels h ON ma.hostel_id = h.id WHERE ma.manager_id = ? LIMIT 1");
$hStmt->execute([$user['id']]);
$assignedHostel = $hStmt->fetch() ?: $pdo->query("SELECT * FROM hostels ORDER BY id ASC LIMIT 1")->fetch();
$hostelId = (int)$assignedHostel['id'];

$selectedMonth = trim($_GET['month'] ?? date('Y-m'));


$occStmt = $pdo->prepare("
    SELECT 
        COUNT(b.id) as total_beds,
        SUM(CASE WHEN b.status = 'occupied' THEN 1 ELSE 0 END) as occupied_beds
    FROM beds b
    JOIN rooms r ON b.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE bl.hostel_id = ?
");
$occStmt->execute([$hostelId]);
$occ = $occStmt->fetch();
$totalBeds = (int)($occ['total_beds'] ?? 0);
$occupiedBeds = (int)($occ['occupied_beds'] ?? 0);
$occupancyRate = $totalBeds > 0 ? round(($occupiedBeds / $totalBeds) * 100, 1) : 0.0;


$billStmt = $pdo->prepare("
    SELECT 
        COALESCE(SUM(b.total_amount), 0) as billed,
        COALESCE(SUM(b.paid_amount), 0) as collected,
        COALESCE(SUM(b.due_amount), 0) as due,
        SUM(CASE WHEN b.status IN ('unpaid', 'partially_paid') THEN 1 ELSE 0 END) as pending_bills_count
    FROM bills b
    JOIN boarders bo ON b.boarder_id = bo.id
    JOIN seat_allocations sa ON sa.boarder_id = bo.id AND sa.status = 'active'
    JOIN beds bd ON sa.bed_id = bd.id
    JOIN rooms r ON bd.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE bl.hostel_id = ? AND b.billing_month = ?
");
$billStmt->execute([$hostelId, $selectedMonth]);
$billsSummary = $billStmt->fetch();


$expStmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM bazar_expenses WHERE hostel_id = ? AND DATE_FORMAT(expense_date, '%Y-%m') = ?");
$expStmt->execute([$hostelId, $selectedMonth]);
$totalExpense = (float)$expStmt->fetchColumn();


$compStmt = $pdo->prepare("
    SELECT 
        COUNT(*) as total_complaints,
        SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) as resolved_count,
        SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending_count
    FROM complaints
    WHERE hostel_id = ? AND DATE_FORMAT(created_at, '%Y-%m') = ?
");
$compStmt->execute([$hostelId, $selectedMonth]);
$compSummary = $compStmt->fetch();

$page_title = 'Manager Reports';
$page_heading = 'Operational Reports & Statistics';
$page_subheading = e($assignedHostel['name']) . ' - Monthly residency, fee collections, and maintenance report';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      <div class="table-toolbar">
        <form method="GET" action="<?= BASE_URL ?>/manager/reports.php" style="display: flex; gap: 0.75rem; align-items: center;">
          <input type="month" name="month" class="form-control" style="width: auto;" value="<?= e($selectedMonth) ?>">
          <button type="submit" class="btn btn-secondary">Filter Month</button>
        </form>

        <a href="<?= BASE_URL ?>/manager/manager_report_pdf.php?month=<?= urlencode($selectedMonth) ?>" target="_blank" class="btn btn-primary">
          Export Manager PDF Report
        </a>
      </div>

      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Bed Occupancy Rate</div>
            <div class="stat-value font-mono"><?= $occupancyRate ?>%</div>
            <div class="stat-sub"><span><?= $occupiedBeds ?> / <?= $totalBeds ?> Beds Occupied</span></div>
          </div>
          <div class="stat-icon icon-teal">🏠</div>
        </div>

        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Total Revenue Collected</div>
            <div class="stat-value font-mono" style="color: var(--success);"><?= formatCurrency($billsSummary['collected']) ?></div>
            <div class="stat-sub"><span>Invoiced: <?= formatCurrency($billsSummary['billed']) ?></span></div>
          </div>
          <div class="stat-icon icon-green">💵</div>
        </div>

        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Pending Dues & Bills</div>
            <div class="stat-value font-mono" style="color: var(--danger);"><?= formatCurrency($billsSummary['due']) ?></div>
            <div class="stat-sub"><span><?= (int)$billsSummary['pending_bills_count'] ?> Unpaid / Due Bills</span></div>
          </div>
          <div class="stat-icon icon-rose">⚠️</div>
        </div>

        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Complaints Resolved</div>
            <div class="stat-value font-mono" style="color: var(--success);"><?= (int)$compSummary['resolved_count'] ?> / <?= (int)$compSummary['total_complaints'] ?></div>
            <div class="stat-sub"><span><?= (int)$compSummary['pending_count'] ?> Pending Tickets</span></div>
          </div>
          <div class="stat-icon icon-blue">🛠️</div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Monthly Operational Review - <?= formatDate($selectedMonth . '-01', 'F Y') ?></h3>
        </div>
        <div style="padding: 1rem 0; line-height: 1.8;">
          <p><strong>Residence Hall:</strong> <?= e($assignedHostel['name']) ?></p>
          <p><strong>Supervisor:</strong> <?= e($user['name']) ?> (<?= e($user['phone']) ?>)</p>
          <p><strong>Food Expense Outlay:</strong> <?= formatCurrency($totalExpense) ?> spent across grocery and kitchen supplies.</p>
          <p><strong>Collection Efficiency:</strong> <?= (float)$billsSummary['billed'] > 0 ? round(((float)$billsSummary['collected'] / (float)$billsSummary['billed']) * 100, 1) : 100 ?>% of billed dues collected.</p>
        </div>
      </div>
    </div> 
<?php require_once __DIR__ . '/includes/footer.php'; ?>
