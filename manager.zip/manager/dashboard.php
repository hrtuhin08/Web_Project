<?php






declare(strict_types=1);
$required_role = 'manager';
require_once __DIR__ . '/includes/role_check.php';

$user = currentUser();
$pdo = getDBConnection();
$currentMonth = date('Y-m');


$hStmt = $pdo->prepare("
    SELECT h.* 
    FROM manager_assignments ma
    JOIN hostels h ON ma.hostel_id = h.id
    WHERE ma.manager_id = ?
    LIMIT 1
");
$hStmt->execute([$user['id']]);
$assignedHostel = $hStmt->fetch();

if (!$assignedHostel) {
    
    $assignedHostel = $pdo->query("SELECT * FROM hostels ORDER BY id ASC LIMIT 1")->fetch();
}

$hostelId = (int)$assignedHostel['id'];


$boarderCountStmt = $pdo->prepare("
    SELECT COUNT(DISTINCT b.id)
    FROM seat_allocations sa
    JOIN boarders b ON sa.boarder_id = b.id
    JOIN beds bd ON sa.bed_id = bd.id
    JOIN rooms r ON bd.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE bl.hostel_id = ? AND sa.status = 'active'
");
$boarderCountStmt->execute([$hostelId]);
$totalBoarders = (int)$boarderCountStmt->fetchColumn();


$bedMetricsStmt = $pdo->prepare("
    SELECT 
        COUNT(b.id) as total_beds,
        SUM(CASE WHEN b.status = 'occupied' THEN 1 ELSE 0 END) as occupied_beds,
        SUM(CASE WHEN b.status = 'vacant' THEN 1 ELSE 0 END) as vacant_beds
    FROM beds b
    JOIN rooms r ON b.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE bl.hostel_id = ?
");
$bedMetricsStmt->execute([$hostelId]);
$bedMetrics = $bedMetricsStmt->fetch();


$complaintsStmt = $pdo->prepare("SELECT COUNT(*) FROM complaints WHERE hostel_id = ? AND status = 'Pending'");
$complaintsStmt->execute([$hostelId]);
$pendingComplaints = (int)$complaintsStmt->fetchColumn();


$billStmt = $pdo->prepare("
    SELECT 
        COALESCE(SUM(b.paid_amount), 0) as monthly_revenue,
        SUM(CASE WHEN b.status IN ('unpaid', 'partially_paid') THEN 1 ELSE 0 END) as unpaid_count
    FROM bills b
    JOIN boarders bo ON b.boarder_id = bo.id
    JOIN seat_allocations sa ON sa.boarder_id = bo.id AND sa.status = 'active'
    JOIN beds bd ON sa.bed_id = bd.id
    JOIN rooms r ON bd.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE bl.hostel_id = ? AND b.billing_month = ?
");
$billStmt->execute([$hostelId, $currentMonth]);
$billData = $billStmt->fetch();


$recentComplaintsStmt = $pdo->prepare("
    SELECT c.*, u.name as boarder_name, b.student_id, r.room_number, bd.bed_number
    FROM complaints c
    JOIN boarders b ON c.boarder_id = b.id
    JOIN users u ON b.user_id = u.id
    LEFT JOIN seat_allocations sa ON sa.boarder_id = b.id AND sa.status = 'active'
    LEFT JOIN beds bd ON sa.bed_id = bd.id
    LEFT JOIN rooms r ON bd.room_id = r.id
    WHERE c.hostel_id = ?
    ORDER BY c.created_at DESC
    LIMIT 5
");
$recentComplaintsStmt->execute([$hostelId]);
$recentComplaints = $recentComplaintsStmt->fetchAll();


$recentPaymentsStmt = $pdo->prepare("
    SELECT p.*, u.name as boarder_name, b.student_id, bi.billing_month
    FROM payments p
    JOIN boarders b ON p.boarder_id = b.id
    JOIN users u ON b.user_id = u.id
    JOIN bills bi ON p.bill_id = bi.id
    JOIN seat_allocations sa ON sa.boarder_id = b.id AND sa.status = 'active'
    JOIN beds bd ON sa.bed_id = bd.id
    JOIN rooms r ON bd.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE bl.hostel_id = ?
    ORDER BY p.payment_date DESC
    LIMIT 5
");
$recentPaymentsStmt->execute([$hostelId]);
$recentPayments = $recentPaymentsStmt->fetchAll();

$page_title = 'Manager Dashboard';
$page_heading = e($assignedHostel['name']) . ' - Manager Portal';
$page_subheading = 'Supervising occupancy, maintenance, billing, and resident inquiries';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Total Boarders</div>
            <div class="stat-value"><?= $totalBoarders ?></div>
            <div class="stat-sub"><span>Resident students</span></div>
          </div>
          <div class="stat-icon icon-teal">👥</div>
        </div>

        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Occupied Seats</div>
            <div class="stat-value font-mono" style="color: var(--danger);"><?= (int)($bedMetrics['occupied_beds'] ?? 0) ?></div>
            <div class="stat-sub"><span>Out of <?= (int)($bedMetrics['total_beds'] ?? 0) ?> capacity</span></div>
          </div>
          <div class="stat-icon icon-rose">🛏️</div>
        </div>

        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Vacant Seats</div>
            <div class="stat-value font-mono" style="color: var(--success);"><?= (int)($bedMetrics['vacant_beds'] ?? 0) ?></div>
            <div class="stat-sub"><a href="<?= BASE_URL ?>/manager/allocate_seat.php" style="color: var(--primary); font-weight: 600;">Allocate Seat &rarr;</a></div>
          </div>
          <div class="stat-icon icon-green">✅</div>
        </div>

        <div class="stat-card">
          <div class="stat-content">
            <div class="stat-label">Pending Complaints</div>
            <div class="stat-value font-mono" style="color: <?= $pendingComplaints > 0 ? 'var(--warning)' : 'var(--text-dark)' ?>;">
              <?= $pendingComplaints ?>
            </div>
            <div class="stat-sub"><a href="<?= BASE_URL ?>/manager/complaints.php" style="color: var(--primary); font-weight: 600;">View complaints</a></div>
          </div>
          <div class="stat-icon icon-amber">⚠️</div>
        </div>
      </div>

      
      <div style="display: flex; gap: 1rem; margin-bottom: 1.75rem; flex-wrap: wrap;">
        <a href="<?= BASE_URL ?>/manager/seat_map.php" class="btn btn-primary">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"></polygon><line x1="8" y1="2" x2="8" y2="18"></line><line x1="16" y1="6" x2="16" y2="22"></line></svg>
          Open Visual Seat Map
        </a>
        <a href="<?= BASE_URL ?>/manager/allocate_seat.php" class="btn btn-secondary">
          + Assign New Student Seat
        </a>
        <a href="<?= BASE_URL ?>/manager/bills.php" class="btn btn-secondary">
          💳 Generate Monthly Bills
        </a>
      </div>

      <div class="dashboard-grid-2">
        
        <div class="card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Resident Issues & Complaints</h3>
              <p class="card-subtitle">Maintenance tickets awaiting supervisor action</p>
            </div>
            <a href="<?= BASE_URL ?>/manager/complaints.php" class="btn btn-outline btn-sm">All Complaints</a>
          </div>

          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th>Boarder</th>
                  <th>Category</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php if (!empty($recentComplaints)): ?>
                  <?php foreach ($recentComplaints as $c): ?>
                    <tr>
                      <td>
                        <strong><?= e($c['boarder_name']) ?></strong>
                        <div style="font-size: 0.78rem; color: var(--text-muted);"><?= e($c['room_number'] ?? 'N/A') ?> - <?= e($c['bed_number'] ?? '') ?></div>
                      </td>
                      <td><span class="badge badge-info"><?= e($c['category']) ?></span></td>
                      <td>
                        <span class="badge badge-<?= strtolower(e($c['status'])) === 'resolved' ? 'resolved' : 'pending' ?>">
                          <?= e($c['status']) ?>
                        </span>
                      </td>
                      <td>
                        <a href="<?= BASE_URL ?>/manager/complaints.php" class="btn btn-secondary btn-sm">Inspect</a>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr><td colspan="4" style="text-align: center; padding: 2rem;">No pending complaints.</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>

        
        <div class="card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Recent Fee Payments</h3>
              <p class="card-subtitle">Latest verified resident fee transactions</p>
            </div>
            <a href="<?= BASE_URL ?>/manager/bills.php" class="btn btn-outline btn-sm">Billing Ledger</a>
          </div>

          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th>Resident</th>
                  <th>Amount</th>
                  <th>Method</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                <?php if (!empty($recentPayments)): ?>
                  <?php foreach ($recentPayments as $p): ?>
                    <tr>
                      <td>
                        <strong><?= e($p['boarder_name']) ?></strong>
                        <div style="font-size: 0.78rem; color: var(--text-muted);"><?= e($p['student_id']) ?></div>
                      </td>
                      <td class="font-mono" style="font-weight: 700; color: var(--success);">
                        <?= formatCurrency($p['amount']) ?>
                      </td>
                      <td><span class="badge badge-info"><?= e($p['payment_method']) ?></span></td>
                      <td class="font-mono" style="font-size: 0.8rem;"><?= formatDate($p['payment_date'], 'M d') ?></td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr><td colspan="4" style="text-align: center; padding: 2rem;">No recent payment records.</td></tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </div> 
<?php require_once __DIR__ . '/includes/footer.php'; ?>
