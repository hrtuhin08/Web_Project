<?php






declare(strict_types=1);
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

if (!isLoggedIn() || !hasRole(['manager', 'admin'])) {
    die('Unauthorized access.');
}

$user = currentUser();
$pdo = getDBConnection();
$selectedMonth = trim($_GET['month'] ?? date('Y-m'));

$hStmt = $pdo->prepare("SELECT h.* FROM manager_assignments ma JOIN hostels h ON ma.hostel_id = h.id WHERE ma.manager_id = ? LIMIT 1");
$hStmt->execute([$user['id']]);
$assignedHostel = $hStmt->fetch() ?: $pdo->query("SELECT * FROM hostels ORDER BY id ASC LIMIT 1")->fetch();
$hostelId = (int)$assignedHostel['id'];


$occStmt = $pdo->prepare("
    SELECT 
        COUNT(b.id) as total_beds,
        SUM(CASE WHEN b.status = 'occupied' THEN 1 ELSE 0 END) as occupied_beds,
        SUM(CASE WHEN b.status = 'vacant' THEN 1 ELSE 0 END) as vacant_beds
    FROM beds b
    JOIN rooms r ON b.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE bl.hostel_id = ?
");
$occStmt->execute([$hostelId]);
$occ = $occStmt->fetch();


$billStmt = $pdo->prepare("
    SELECT 
        COALESCE(SUM(b.total_amount), 0) as billed,
        COALESCE(SUM(b.paid_amount), 0) as collected,
        COALESCE(SUM(b.due_amount), 0) as due
    FROM bills b
    JOIN boarders bo ON b.boarder_id = bo.id
    JOIN seat_allocations sa ON sa.boarder_id = bo.id AND sa.status = 'active'
    JOIN beds bd ON sa.bed_id = bd.id
    JOIN rooms r ON bd.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE bl.hostel_id = ? AND b.billing_month = ?
");
$billStmt->execute([$hostelId, $selectedMonth]);
$fin = $billStmt->fetch();

ob_start();
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Hostel Manager Monthly Report</title>
  <style>
    body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size: 11px; color: #1e293b; margin: 25px; line-height: 1.5; }
    .header { text-align: center; border-bottom: 2px solid #0d9488; padding-bottom: 15px; margin-bottom: 20px; }
    .header h1 { font-size: 18px; margin: 0 0 5px; color: #0f172a; }
    .summary-table { width: 100%; border-collapse: collapse; margin-bottom: 25px; }
    .summary-table td { width: 50%; padding: 12px; border: 1px solid #cbd5e1; vertical-align: top; }
    .section-title { font-size: 13px; font-weight: bold; color: #0d9488; margin-bottom: 8px; text-transform: uppercase; }
    .metric-row { display: flex; justify-content: space-between; margin-bottom: 6px; }
    .sig-table { width: 100%; margin-top: 50px; }
    .sig-line { border-top: 1px solid #94a3b8; width: 180px; text-align: center; padding-top: 5px; font-size: 10px; color: #64748b; }
  </style>
</head>
<body>
  <div class="header">
    <h1><?= e($assignedHostel['name']) ?></h1>
    <p>Hostel Manager's Monthly Operations & Occupancy Summary</p>
    <p><strong>Reporting Month:</strong> <?= formatDate($selectedMonth . '-01', 'F Y') ?> | <strong>Manager:</strong> <?= e($user['name']) ?></p>
  </div>

  <table class="summary-table">
    <tr>
      <td>
        <div class="section-title">Residency & Bed Occupancy</div>
        <p><strong>Total Capacity:</strong> <?= (int)$occ['total_beds'] ?> Beds</p>
        <p><strong>Occupied Beds:</strong> <?= (int)$occ['occupied_beds'] ?></p>
        <p><strong>Vacant / Available:</strong> <?= (int)$occ['vacant_beds'] ?></p>
        <p><strong>Occupancy Rate:</strong> <?= (int)$occ['total_beds'] > 0 ? round(((int)$occ['occupied_beds'] / (int)$occ['total_beds']) * 100, 1) : 0 ?>%</p>
      </td>
      <td>
        <div class="section-title">Billing & Collections</div>
        <p><strong>Total Invoiced:</strong> <?= formatCurrency($fin['billed']) ?></p>
        <p><strong>Verified Collections:</strong> <?= formatCurrency($fin['collected']) ?></p>
        <p><strong>Outstanding Balance:</strong> <?= formatCurrency($fin['due']) ?></p>
        <p><strong>Collection Ratio:</strong> <?= (float)$fin['billed'] > 0 ? round(((float)$fin['collected'] / (float)$fin['billed']) * 100, 1) : 100 ?>%</p>
      </td>
    </tr>
  </table>

  <table class="sig-table">
    <tr>
      <td>
        <div class="sig-line"><?= e($user['name']) ?><br>Hostel Manager</div>
      </td>
      <td style="text-align: right;">
        <div class="sig-line" style="margin-left: auto;">Hostel Provost / Dean of Students</div>
      </td>
    </tr>
  </table>
</body>
</html>
<?php
$html = ob_get_clean();

$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$dompdf = new Dompdf($options);
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

$filename = "Manager_Report_{$selectedMonth}.pdf";
$dompdf->stream($filename, ["Attachment" => false]);
exit;
