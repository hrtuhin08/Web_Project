<?php





declare(strict_types=1);
$required_role = 'manager';
require_once __DIR__ . '/includes/role_check.php';

$user = currentUser();
$pdo = getDBConnection();

$hStmt = $pdo->prepare("SELECT h.* FROM manager_assignments ma JOIN hostels h ON ma.hostel_id = h.id WHERE ma.manager_id = ? LIMIT 1");
$hStmt->execute([$user['id']]);
$assignedHostel = $hStmt->fetch() ?: $pdo->query("SELECT * FROM hostels ORDER BY id ASC LIMIT 1")->fetch();
$hostelId = (int)$assignedHostel['id'];

$selectedCategory = trim($_GET['category'] ?? '');
$selectedStatus = trim($_GET['status'] ?? '');

$complaintSql = "
    SELECT 
        c.*,
        u.name as boarder_name,
        u.phone as boarder_phone,
        bo.student_id,
        r.room_number,
        bd.bed_number
    FROM complaints c
    JOIN boarders bo ON c.boarder_id = bo.id
    JOIN users u ON bo.user_id = u.id
    LEFT JOIN seat_allocations sa ON sa.boarder_id = bo.id AND sa.status = 'active'
    LEFT JOIN beds bd ON sa.bed_id = bd.id
    LEFT JOIN rooms r ON bd.room_id = r.id
    WHERE c.hostel_id = :hid
";

$params = ['hid' => $hostelId];
if (!empty($selectedCategory)) {
    $complaintSql .= " AND c.category = :cat";
    $params['cat'] = $selectedCategory;
}
if (!empty($selectedStatus)) {
    $complaintSql .= " AND c.status = :st";
    $params['st'] = $selectedStatus;
}

$complaintSql .= " ORDER BY c.created_at DESC";

$stmt = $pdo->prepare($complaintSql);
$stmt->execute($params);
$complaints = $stmt->fetchAll();

$page_title = 'Complaints';
$page_heading = 'Complaints & Maintenance Requests';
$page_subheading = e($assignedHostel['name']) . ' - Review and resolve resident maintenance tickets';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      <div class="table-toolbar">
        <form method="GET" action="<?= BASE_URL ?>/manager/complaints.php" style="display: flex; gap: 0.75rem; flex-wrap: wrap; align-items: center;">
          <select name="category" class="form-control" style="width: auto;">
            <option value="">All Categories</option>
            <?php foreach (['Electrical', 'Plumbing', 'Internet', 'Furniture', 'Cleaning', 'Security', 'Other'] as $cat): ?>
              <option value="<?= $cat ?>" <?= $selectedCategory === $cat ? 'selected' : '' ?>><?= $cat ?></option>
            <?php endforeach; ?>
          </select>

          <select name="status" class="form-control" style="width: auto;">
            <option value="">All Statuses</option>
            <option value="Pending" <?= $selectedStatus === 'Pending' ? 'selected' : '' ?>>Pending</option>
            <option value="In Progress" <?= $selectedStatus === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
            <option value="Resolved" <?= $selectedStatus === 'Resolved' ? 'selected' : '' ?>>Resolved</option>
          </select>

          <button type="submit" class="btn btn-secondary">Filter</button>
        </form>
      </div>

      <div class="card">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Resident</th>
                <th>Location</th>
                <th>Category</th>
                <th>Issue Description</th>
                <th>Logged</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!empty($complaints)): ?>
                <?php foreach ($complaints as $c): ?>
                  <tr>
                    <td>
                      <strong><?= e($c['boarder_name']) ?></strong>
                      <div style="font-size: 0.78rem; color: var(--text-muted);"><?= e($c['boarder_phone']) ?></div>
                    </td>
                    <td><?= e($c['room_number'] ?? 'N/A') ?> - <?= e($c['bed_number'] ?? '') ?></td>
                    <td><span class="badge badge-info"><?= e($c['category']) ?></span></td>
                    <td>
                      <div style="max-width: 320px;"><?= e($c['description']) ?></div>
                      <?php if (!empty($c['response_note'])): ?>
                        <div style="margin-top: 0.35rem; font-size: 0.8rem; color: var(--primary-dark); background: var(--primary-light); padding: 0.3rem 0.5rem; border-radius: var(--radius-xs);">
                          <strong>Manager Note:</strong> <?= e($c['response_note']) ?>
                        </div>
                      <?php endif; ?>
                    </td>
                    <td class="font-mono" style="font-size: 0.8rem;"><?= timeAgo($c['created_at']) ?></td>
                    <td>
                      <span class="badge badge-<?= strtolower(str_replace(' ', '_', e($c['status']))) ?>">
                        <?= e($c['status']) ?>
                      </span>
                    </td>
                    <td>
                      <button class="btn btn-secondary btn-sm" onclick='openResolveModal(<?= json_encode($c) ?>)'>
                        Update Status
                      </button>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="7" style="text-align: center; padding: 2.5rem;">No complaints found.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div> 

    
    <div class="modal-backdrop" id="resolveModal">
      <div class="modal-dialog">
        <div class="modal-header">
          <h3>Update Complaint Status</h3>
          <button class="modal-close" onclick="closeModal('resolveModal')">&times;</button>
        </div>
        <form method="POST" action="<?= BASE_URL ?>/actions/complaint.php" data-validate="true">
          <input type="hidden" name="action" value="update_status">
          <input type="hidden" name="complaint_id" id="comp_id">
          <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

          <div class="modal-body">
            <div class="alert alert-info">
              Resident: <strong id="comp_boarder"></strong> &bull; Category: <span id="comp_category"></span>
              <p id="comp_desc" style="margin-top: 0.5rem; font-size: 0.85rem;"></p>
            </div>

            <div class="form-group">
              <label class="form-label">Update Status <span class="required">*</span></label>
              <select name="status" id="comp_status" class="form-control" required>
                <option value="Pending">Pending</option>
                <option value="In Progress">In Progress (Assigned / Investigating)</option>
                <option value="Resolved">Resolved (Fixed & Closed)</option>
              </select>
            </div>

            <div class="form-group">
              <label class="form-label">Response Note to Resident</label>
              <textarea name="response_note" id="comp_note" class="form-control" rows="3" placeholder="e.g. Electrician visited and replaced the fuse switch."></textarea>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" onclick="closeModal('resolveModal')">Cancel</button>
            <button type="submit" class="btn btn-primary">Save Changes</button>
          </div>
        </form>
      </div>
    </div>

  <script>
    function openResolveModal(c) {
      document.getElementById('comp_id').value = c.id;
      document.getElementById('comp_boarder').textContent = c.boarder_name;
      document.getElementById('comp_category').textContent = c.category;
      document.getElementById('comp_desc').textContent = `"${c.description}"`;
      document.getElementById('comp_status').value = c.status;
      document.getElementById('comp_note').value = c.response_note || '';
      openModal('resolveModal');
    }
  </script>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
