<?php





declare(strict_types=1);
$required_role = 'manager';
require_once __DIR__ . '/includes/role_check.php';

$user = currentUser();
$pdo = getDBConnection();

$hStmt = $pdo->prepare("SELECT h.* FROM manager_assignments ma JOIN hostels h ON ma.hostel_id = h.id WHERE ma.manager_id = ? LIMIT 1");
$hStmt->execute([$user['id']]);
$assignedHostel = $hStmt->fetch() ?: $pdo->query("SELECT * FROM hostels ORDER BY id ASC LIMIT 1")->fetch();
$hostelId = (int)$assignedHostel['id'];


$eligibleStmt = $pdo->query("
    SELECT b.id as boarder_id, b.student_id, b.institution, b.department, u.name, u.phone, u.email
    FROM boarders b
    JOIN users u ON b.user_id = u.id
    WHERE u.status IN ('approved', 'active')
      AND b.id NOT IN (SELECT boarder_id FROM seat_allocations WHERE status = 'active')
    ORDER BY u.name ASC
");
$eligibleBoarders = $eligibleStmt->fetchAll();


$vacantStmt = $pdo->prepare("
    SELECT b.id as bed_id, b.bed_number, r.room_number, r.room_type, r.rent, f.floor_number, bl.name as block_name
    FROM beds b
    JOIN rooms r ON b.room_id = r.id
    JOIN floors f ON r.floor_id = f.id
    JOIN blocks bl ON f.block_id = bl.id
    WHERE bl.hostel_id = ? AND b.status = 'vacant'
    ORDER BY bl.name ASC, r.room_number ASC, b.bed_number ASC
");
$vacantStmt->execute([$hostelId]);
$vacantBeds = $vacantStmt->fetchAll();

$page_title = 'Allocate Seat';
$page_heading = 'Seat Allocation Portal';
$page_subheading = 'Assign approved boarders to vacant beds';

require_once __DIR__ . '/includes/header.php';
?>
<div class="dashboard-layout">
  <?php require_once __DIR__ . '/includes/sidebar.php'; ?>

  <main class="main-wrapper">
    <?php require_once __DIR__ . '/includes/navbar.php'; ?>

    <div class="page-content">
      <div style="max-width: 800px; margin: 0 auto;">
        <div class="card">
          <div class="card-header">
            <div>
              <h3 class="card-title">Assign Bed to Boarder</h3>
              <p class="card-subtitle">Enforcing the rule: 1 bed = 1 boarder; 1 boarder = 1 bed</p>
            </div>
            <a href="<?= BASE_URL ?>/manager/seat_map.php" class="btn btn-secondary btn-sm">&larr; Visual Seat Map</a>
          </div>

          <form method="POST" action="<?= BASE_URL ?>/actions/seat.php" data-validate="true">
            <input type="hidden" name="action" value="allocate">
            <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">

            <div class="form-group">
              <label class="form-label">Select Approved Student <span class="required">*</span></label>
              <select name="boarder_id" class="form-control" required>
                <option value="">-- Choose Approved Student --</option>
                <?php if (!empty($eligibleBoarders)): ?>
                  <?php foreach ($eligibleBoarders as $eb): ?>
                    <option value="<?= $eb['boarder_id'] ?>">
                      <?= e($eb['name']) ?> (ID: <?= e($eb['student_id']) ?> &bull; <?= e($eb['department']) ?>)
                    </option>
                  <?php endforeach; ?>
                <?php else: ?>
                  <option value="" disabled>No unallocated approved students available.</option>
                <?php endif; ?>
              </select>
            </div>

            <div class="form-group">
              <label class="form-label">Select Vacant Bed (in <?= e($assignedHostel['name']) ?>) <span class="required">*</span></label>
              <select name="bed_id" class="form-control" required>
                <option value="">-- Choose Vacant Bed --</option>
                <?php if (!empty($vacantBeds)): ?>
                  <?php foreach ($vacantBeds as $vb): ?>
                    <option value="<?= $vb['bed_id'] ?>">
                      Room <?= e($vb['room_number']) ?> &rsaquo; Bed <?= e($vb['bed_number']) ?> 
                      (<?= e($vb['block_name']) ?>, <?= e($vb['floor_number']) ?>) - Rent: <?= formatCurrency($vb['rent']) ?>/mo
                    </option>
                  <?php endforeach; ?>
                <?php else: ?>
                  <option value="" disabled>No vacant beds currently available in this hostel.</option>
                <?php endif; ?>
              </select>
            </div>

            <div class="form-group">
              <label class="form-label">Allocation Start Date <span class="required">*</span></label>
              <input type="date" name="allocation_date" class="form-control" required value="<?= date('Y-m-d') ?>">
            </div>

            <div style="margin-top: 2rem; display: flex; gap: 1rem;">
              <button type="submit" class="btn btn-primary btn-lg" style="flex: 1;">Confirm & Allocate Seat</button>
              <a href="<?= BASE_URL ?>/manager/seat_map.php" class="btn btn-secondary btn-lg">Cancel</a>
            </div>
          </form>
        </div>
      </div>
    </div> 
<?php require_once __DIR__ . '/includes/footer.php'; ?>
